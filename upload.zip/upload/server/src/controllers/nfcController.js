const db = require('../utils/db');

async function createMapping(req, res, next) {
  try {
    const { seat_id, tag_uid } = req.body;
    const user = req.session.user;
    if (!user) return res.status(401).json({ error: 'Not authenticated' });

    const { rows } = await db.query(
      'INSERT INTO nfc_mappings(mapping_id, seat_id, tag_uid, created_by) VALUES(gen_random_uuid(), $1, $2, $3) RETURNING *',
      [seat_id || null, tag_uid, user.user_id]
    );
    res.status(201).json(rows[0]);
  } catch (err) {
    next(err);
  }
}

async function getMappingByTag(req, res, next) {
  try {
    const { rows } = await db.query(
      'SELECT * FROM nfc_mappings WHERE tag_uid = $1',
      [req.params.tag_uid]
    );
    if (!rows[0]) return res.status(404).json({ error: 'Not found' });
    res.json(rows[0]);
  } catch (err) {
    next(err);
  }
}

module.exports = { createMapping, getMappingByTag };
