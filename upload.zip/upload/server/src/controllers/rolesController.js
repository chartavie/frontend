// controllers/rolesController.js

const db = require('../utils/db');

/**
 * Get list of roles with associated permissions
 */
async function listRoles(req, res, next) {
  try {
    const { rows } = await db.query(`
      SELECT r.role_id, r.name, r.description,
        COALESCE(
          json_agg(
            DISTINCT jsonb_build_object('perm_id', p.perm_id, 'name', p.name)
          ) FILTER (WHERE p.perm_id IS NOT NULL), '[]'
        ) AS perms
      FROM roles r
      LEFT JOIN role_permissions rp ON rp.role_id = r.role_id
      LEFT JOIN permissions p ON p.perm_id = rp.perm_id
      GROUP BY r.role_id
      ORDER BY r.name
    `);
    res.json(rows);
  } catch (err) {
    next(err);
  }
}

/**
 * Get list of all permissions
 */
async function listPerms(req, res, next) {
  try {
    const { rows } = await db.query('SELECT perm_id, name, description FROM permissions ORDER BY name');
    res.json(rows);
  } catch (err) {
    next(err);
  }
}

/**
 * Replace a role's permissions
 */
async function replaceRolePermissions(req, res, next) {
  const { role_id } = req.params;
  const { perm_ids } = req.body;
  const client = await db.pool.connect();
  try {
    await client.query('BEGIN');
    await client.query('DELETE FROM role_permissions WHERE role_id = $1', [role_id]);

    if (perm_ids && perm_ids.length > 0) {
      const placeholders = perm_ids.map((_, i) => `($1, $${i + 2})`).join(', ');
      const values = [role_id, ...perm_ids];
      await client.query(
        `INSERT INTO role_permissions(role_id, perm_id) VALUES ${placeholders}`,
        values
      );
    }

    await client.query('COMMIT');
    res.json({ ok: true });
  } catch (err) {
    await client.query('ROLLBACK');
    next(err);
  } finally {
    client.release();
  }
}

/**
 * Create a new role
 */
async function createRole(req, res, next) {
  try {
    const { name, description } = req.body;
    const { rows } = await db.query(
      'INSERT INTO roles(role_id, name, description) VALUES (gen_random_uuid(), $1, $2) RETURNING role_id, name, description',
      [name, description]
    );
    res.status(201).json(rows[0]);
  } catch (err) {
    next(err);
  }
}

/**
 * Delete a role by ID
 */
async function deleteRole(req, res, next) {
  try {
    const { role_id } = req.params;
    await db.query('DELETE FROM roles WHERE role_id = $1', [role_id]);
    res.json({ ok: true });
  } catch (err) {
    next(err);
  }
}

/**
 * Create a new permission
 */
async function createPerm(req, res, next) {
  try {
    const { name, description } = req.body;
    const { rows } = await db.query(
      'INSERT INTO permissions(perm_id, name, description) VALUES (gen_random_uuid(), $1, $2) RETURNING perm_id, name, description',
      [name, description]
    );
    res.status(201).json(rows[0]);
  } catch (err) {
    next(err);
  }
}

/**
 * Delete a permission by ID
 */
async function deletePerm(req, res, next) {
  try {
    const { perm_id } = req.params;
    await db.query('DELETE FROM permissions WHERE perm_id = $1', [perm_id]);
    res.json({ ok: true });
  } catch (err) {
    next(err);
  }
}

// Export all controller methods
module.exports = {
  listRoles,
  listPerms,
  replaceRolePermissions,
  createRole,
  deleteRole,
  createPerm,
  deletePerm
};
