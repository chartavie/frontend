const db = require('../utils/db');
const slugify = require('slugify');
const { v4: uuidv4 } = require('uuid');

async function listPublic(req, res, next) {
  try {
    const { q, category, tag, from, to } = req.query;
    let where = ['status = \'published\''];
    const params = [];
    if (category) { params.push(category); where.push(`category = $${params.length}`); }
    if (tag) { params.push(tag); where.push(`$${params.length} = ANY(tags)`); }
    if (from) { params.push(from); where.push(`start_time >= $${params.length}`); }
    if (to) { params.push(to); where.push(`end_time <= $${params.length}`); }
    if (q) { params.push('%' + q + '%'); where.push(`(title ILIKE $${params.length} OR description ILIKE $${params.length})`); }
    const whereClause = where.length ? 'WHERE ' + where.join(' AND ') : '';
    const { rows } = await db.query(`SELECT event_id, title, slug, description, category, tags, start_time, end_time, poster_key FROM events ${whereClause} ORDER BY start_time ASC LIMIT 100`, params);
    res.json(rows);
  } catch (err) { next(err); }
}

async function getEvent(req, res, next) {
  try {
    const { id } = req.params;
    const { rows } = await db.query('SELECT * FROM events WHERE event_id = $1', [id]);
    if (!rows[0]) return res.status(404).json({ error: 'Not found' });
    res.json(rows[0]);
  } catch (err) { next(err); }
}

async function createEvent(req, res, next) {
  try {
    const user = req.session.user;
    if (!user) return res.status(401).json({ error: 'Not authenticated' });
    const { title, description, category, tags, venue_id, start_time, end_time, status, photo, poster, logo } = req.body;
    const slug = slugify(title, { lower: true, strict: true }) + '-' + uuidv4().slice(0,8);
    const { rows } = await db.query(
      `INSERT INTO events(event_id, org_id, title, slug, description, category, tags, venue_id, start_time, end_time, status, photo, poster, logo, created_by)
       VALUES(gen_random_uuid(), $1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14) RETURNING *`,
      [user.org_id || null, title, slug, description, category, tags || [], venue_id || null, start_time || null, end_time || null, status || 'draft', photo || null, poster || null, logo || null, user.user_id]
    );
    res.status(201).json(rows[0]);
  } catch (err) { next(err); }
}

async function updateEvent(req, res, next) {
  try {
    const user = req.session.user;
    if (!user) return res.status(401).json({ error: 'Not authenticated' });
    const { id } = req.params;
    const { title, description, category, tags, venue_id, start_time, end_time, status } = req.body;
    const slug = title ? slugify(title, { lower: true, strict: true }) + '-' + uuidv4().slice(0,8) : undefined;
    const q = `UPDATE events SET
  title = COALESCE($1, title),
  slug = COALESCE($2, slug),
  description = COALESCE($3, description),
  category = COALESCE($4, category),
  tags = COALESCE($5, tags),
  venue_id = COALESCE($6, venue_id),
  start_time = COALESCE($7, start_time),
  end_time = COALESCE($8, end_time),
  status = COALESCE($9, status),
  photo = COALESCE($10, photo),
  poster = COALESCE($11, poster),
  logo = COALESCE($12, logo),
  updated_at = now()
  WHERE event_id = $13 RETURNING *`;
    const params = [
      title || null, slug || null, description || null, category || null, tags || null, venue_id || null,
      start_time || null, end_time || null, status || null, photo || null, poster || null, logo || null, id
    ];
    const { rows } = await db.query(q, params);
    if (!rows[0]) return res.status(404).json({ error: 'Not found' });
    res.json(rows[0]);
  } catch (err) { next(err); }
}

async function deleteEvent(req, res, next) {
  try {
    const { id } = req.params;
    await db.query('DELETE FROM events WHERE event_id = $1', [id]);
    res.json({ ok: true });
  } catch (err) { next(err); }
}

module.exports = { listPublic, getEvent, createEvent, updateEvent, deleteEvent };
