const db = require('../utils/db');
const { generateSecret, verifyTOTP, toDataURL } = require('../services/twofaService');

async function setup(req, res, next) {
  try {
    const user = req.session.user;
    if (!user) return res.status(401).json({ error: 'Not authenticated' });
    const secret = generateSecret();
    // store in DB (base32)
    await db.query('UPDATE users SET twofa_secret = $1 WHERE user_id = $2', [secret.base32, user.user_id]);
    const url = secret.otpauth_url;
    const qr = await toDataURL(url);
    res.json({ qr, secret: secret.base32 });
  } catch (err) { next(err); }
}

async function verify(req, res, next) {
  try {
    const user = req.session.user;
    const { token } = req.body;
    const { rows } = await db.query('SELECT twofa_secret FROM users WHERE user_id = $1', [user.user_id]);
    const secret = rows[0] && rows[0].twofa_secret;
    if (!secret) return res.status(400).json({ error: '2FA not set up' });
    const ok = verifyTOTP(secret, token);
    if (!ok) return res.status(400).json({ error: 'Invalid token' });
    await db.query('UPDATE users SET twofa_enabled = true WHERE user_id = $1', [user.user_id]);
    res.json({ ok: true });
  } catch (err) { next(err); }
}

module.exports = { setup, verify };
