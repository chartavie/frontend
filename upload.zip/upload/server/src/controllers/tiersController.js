const db = require('../utils/db');

async function listTiers(req, res, next) {
  try {
    const { seatmap_id } = req.query;
    let rows;
    if (seatmap_id) {
      ({ rows } = await db.query(
        'SELECT * FROM seating_tiers WHERE seatmap_id = $1 ORDER BY name',
        [seatmap_id]
      ));
    } else {
      ({ rows } = await db.query(
        'SELECT * FROM seating_tiers ORDER BY name'
      ));
    }
    res.json(rows);
  } catch (err) {
    next(err);
  }
}

async function createTier(req, res, next) {
  try {
    const user = req.session.user;
    if (!user) return res.status(401).json({ error: 'Not authenticated' });
    const { seatmap_id, name, price_cents, metadata } = req.body;
    const { rows } = await db.query(
      'INSERT INTO seating_tiers(tier_id, seatmap_id, name, price_cents, metadata) VALUES(gen_random_uuid(), $1, $2, $3, $4) RETURNING *',
      [seatmap_id, name, price_cents || 0, metadata || {}]
    );
    res.status(201).json(rows[0]);
  } catch (err) {
    next(err);
  }
}

async function updateTier(req, res, next) {
  try {
    const user = req.session.user;
    if (!user) return res.status(401).json({ error: 'Not authenticated' });
    const { name, price_cents, metadata } = req.body;
    const { id } = req.params;
    const { rows } = await db.query(
      'UPDATE seating_tiers SET name = COALESCE($1, name), price_cents = COALESCE($2, price_cents), metadata = COALESCE($3, metadata) WHERE tier_id = $4 RETURNING *',
      [name || null, price_cents || null, metadata || null, id]
    );
    if (!rows[0]) return res.status(404).json({ error: 'Not found' });
    res.json(rows[0]);
  } catch (err) {
    next(err);
  }
}

async function deleteTier(req, res, next) {
  try {
    const user = req.session.user;
    if (!user) return res.status(401).json({ error: 'Not authenticated' });
    const { id } = req.params;
    await db.query('DELETE FROM seating_tiers WHERE tier_id = $1', [id]);
    res.json({ ok: true });
  } catch (err) {
    next(err);
  }
}

module.exports = { listTiers, createTier, updateTier, deleteTier };
