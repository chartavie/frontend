const db = require('../utils/db');
const { v4: uuidv4 } = require('uuid');

async function listSeatmaps(req, res, next) {
  try {
    const { venue_id } = req.query;
    const params = [];
    let where = '';
    if (venue_id) { params.push(venue_id); where = 'WHERE venue_id = $1'; }
    const { rows } = await db.query(`SELECT * FROM seatmaps ${where} ORDER BY created_at DESC`, params);
    res.json(rows);
  } catch (err) { next(err); }
}

async function getSeatmap(req, res, next) {
  try {
    const { id } = req.params;
    const { rows } = await db.query('SELECT * FROM seatmaps WHERE seatmap_id = $1', [id]);
    if (!rows[0]) return res.status(404).json({ error: 'Not found' });
    // attach tiers and seats
    const seatmap = rows[0];
    const tiers = await db.query('SELECT * FROM seating_tiers WHERE seatmap_id = $1', [id]);
    const seats = await db.query('SELECT * FROM seats WHERE seatmap_id = $1', [id]);
    seatmap.tiers = tiers.rows;
    seatmap.seats = seats.rows;
    res.json(seatmap);
  } catch (err) { next(err); }
}

async function createSeatmap(req, res, next) {
  try {
    const user = req.session.user;
    if (!user) return res.status(401).json({ error: 'Not authenticated' });
    const { venue_id, name, type, svg_content, layout } = req.body;
    const { rows } = await db.query(
      'INSERT INTO seatmaps(seatmap_id, venue_id, name, type, svg_content, layout, created_by) VALUES(gen_random_uuid(), $1,$2,$3,$4,$5,$6) RETURNING *',
      [venue_id, name, type || 'reserved', svg_content || null, layout || {}, user.user_id]
    );
    res.status(201).json(rows[0]);
  } catch (err) { next(err); }
}

async function updateSeatmap(req, res, next) {
  try {
    const { id } = req.params;
    const { name, type, svg_content, layout } = req.body;
    const q = 'UPDATE seatmaps SET name = COALESCE($1, name), type = COALESCE($2, type), svg_content = COALESCE($3, svg_content), layout = COALESCE($4, layout), updated_at = now() WHERE seatmap_id = $5 RETURNING *';
    const params = [name || null, type || null, svg_content || null, layout || null, id];
    const { rows } = await db.query(q, params);
    if (!rows[0]) return res.status(404).json({ error: 'Not found' });
    res.json(rows[0]);
  } catch (err) { next(err); }
}

async function deleteSeatmap(req, res, next) {
  try {
    const { id } = req.params;
    await db.query('DELETE FROM seatmaps WHERE seatmap_id = $1', [id]);
    res.json({ ok: true });
  } catch (err) { next(err); }
}

module.exports = { listSeatmaps, getSeatmap, createSeatmap, updateSeatmap, deleteSeatmap };
