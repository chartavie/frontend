const redis = require('../utils/redis');

async function lockSeat(req, res, next) {
  try {
    const { seat_id, ttl_seconds = 300 } = req.body;
    const user = req.session.user;
    if (!user) return res.status(401).json({ error: 'Not authenticated' });

    const key = `seatlock:${seat_id}`;
    const exists = await redis.get(key);
    if (exists) return res.status(409).json({ error: 'Seat already locked' });

    const payload = JSON.stringify({
      user_id: user.user_id,
      expires_at: Date.now() + ttl_seconds * 1000
    });
    await redis.set(key, payload, 'EX', ttl_seconds);

    res.json({ ok: true, expires_in: ttl_seconds });
  } catch (e) {
    next(e);
  }
}

async function unlockSeat(req, res, next) {
  try {
    const { seat_id } = req.body;
    const user = req.session.user;
    if (!user) return res.status(401).json({ error: 'Not authenticated' });

    const key = `seatlock:${seat_id}`;
    const val = await redis.get(key);
    if (!val) return res.json({ ok: true });

    const payload = JSON.parse(val);
    if (payload.user_id !== user.user_id && user.role_id !== 1)
      return res.status(403).json({ error: 'Not allowed' });

    await redis.del(key);
    res.json({ ok: true });
  } catch (e) {
    next(e);
  }
}

async function checkLock(req, res, next) {
  try {
    const seat_id = req.params.seat_id;
    const val = await redis.get(`seatlock:${seat_id}`);
    if (!val) return res.json({ locked: false });

    const payload = JSON.parse(val);
    res.json({
      locked: true,
      locker: payload.user_id,
      expires_at: payload.expires_at
    });
  } catch (e) {
    next(e);
  }
}

module.exports = { lockSeat, unlockSeat, checkLock };
