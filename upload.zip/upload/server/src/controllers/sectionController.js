const db = require('../utils/db');

/**
 * List all sections for a venue
 */
async function listSections(req, res, next) {
  try {
    const { venue_id } = req.params;
    const { rows } = await db.query(
      `SELECT * FROM sections WHERE venue_id = $1 ORDER BY name`,
      [venue_id]
    );
    res.json(rows);
  } catch (err) {
    next(err);
  }
}

/**
 * Get a single section by ID
 */
async function getSection(req, res, next) {
  try {
    const { section_id } = req.params;
    const { rows } = await db.query(
      `SELECT * FROM sections WHERE section_id = $1`,
      [section_id]
    );
    if (rows.length === 0) return res.status(404).json({ error: 'Section not found' });
    res.json(rows[0]);
  } catch (err) {
    next(err);
  }
}

/**
 * Create a new section
 */
async function createSection(req, res, next) {
  try {
    const { venue_id, name, row_count, col_count, x, y, metadata } = req.body;
    const { rows } = await db.query(
      `INSERT INTO sections (venue_id, name, row_count, col_count, x, y, metadata)
       VALUES ($1, $2, $3, $4, $5, $6, $7)
       RETURNING *`,
      [venue_id, name, row_count, col_count, x, y, metadata || {}]
    );
    res.status(201).json(rows[0]);
  } catch (err) {
    next(err);
  }
}

async function updateSection(req, res, next) {
  try {
    const { section_id } = req.params;
    const { name, row_count, col_count, x, y, metadata } = req.body;
    const { rows } = await db.query(
      `UPDATE sections SET
        name = COALESCE($2, name),
        row_count = COALESCE($3, row_count),
        col_count = COALESCE($4, col_count),
        x = COALESCE($5, x),
        y = COALESCE($6, y),
        metadata = COALESCE($7, metadata)
       WHERE section_id = $1
       RETURNING *`,
      [section_id, name, row_count, col_count, x, y, metadata]
    );
    if (rows.length === 0) return res.status(404).json({ error: 'Section not found' });
    res.json(rows[0]);
  } catch (err) {
    next(err);
  }
}

/**
 * Delete a section
 */
async function deleteSection(req, res, next) {
  try {
    const { section_id } = req.params;
    await db.query(
      `DELETE FROM sections WHERE section_id = $1`,
      [section_id]
    );
    res.json({ ok: true });
  } catch (err) {
    next(err);
  }
}

// Export all controller methods
module.exports = {
  listSections,
  getSection,
  createSection,
  updateSection,
  deleteSection
};