const db = require('../utils/db');
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');
const jwt = require('jsonwebtoken');
const { sendEmail } = require('../services/mailService');
const { MAX_FAILED_ATTEMPTS = 5, LOCKOUT_BASE_MINUTES = 15, LOCKOUT_MAX_MINUTES = 60 } = process.env;

// helper to get user by email
async function findUserByEmail(email) {
  const { rows } = await db.query('SELECT * FROM users WHERE email = $1', [email]);
  return rows[0];
}

async function register(req, res, next) {
  try {
    const { name, email, password, phone } = req.body;
    const existing = await findUserByEmail(email);
    if (existing) return res.status(400).json({ error: 'Email already registered' });
    const hash = await bcrypt.hash(password, 10);
    const { rows } = await db.query('INSERT INTO users(full_name, email, password_hash, phone, is_verified) VALUES($1,$2,$3,$4,$5) RETURNING user_id, full_name, email, phone', [name, email, hash, phone, false]);
    const user = rows[0];
    // create verification token
    const vtoken = uuidv4();
    const expires = new Date(Date.now() + 24*60*60*1000);
    await db.query('INSERT INTO email_verifications(token, user_id, expires_at) VALUES($1,$2,$3)', [vtoken, user.user_id, expires]);
    const link = `${process.env.APP_BASE_URL || 'http://localhost:3000'}/verify-email?token=${vtoken}`;
    // send email (non-fatal)
    try {
      if (process.env.SENDGRID_API_KEY && process.env.SENDGRID_API_KEY.startsWith('SG.')) {
        await sendEmail(email, 'Verify your email', `<p>Please verify: <a href="${link}">${link}</a></p>`);
      } else {
        console.warn('[auth.register] SendGrid API key missing or invalid; skipping email send');
      }
    } catch (mailErr) {
      console.error('[auth.register] SendGrid/sendEmail failed (non-fatal):', mailErr);
      // continue without throwing
    }

    // auto-verify in development if requested
    if (process.env.DEV_AUTO_VERIFY === 'true' || process.env.NODE_ENV !== 'production') {
      await db.query('UPDATE users SET is_verified = true WHERE user_id = $1', [user.user_id]);
      console.info(`[dev] auto-verified user ${email}`);
    }
    // respond success to client
    res.status(201).json({ ok: true, message: 'Registered' });
  } catch (err) {
    console.error('[auth.register] error', err);
    next(err);
  }
}

// exponential lock calculation: base * 2^(lock_count-1)
function computeLockMinutes(lockCount) {
  const base = parseInt(process.env.LOCKOUT_BASE_MINUTES || '15', 10);
  const maxm = parseInt(process.env.LOCKOUT_MAX_MINUTES || '60', 10);
  const minutes = Math.min(maxm, base * Math.pow(2, Math.max(0, (lockCount - 1))));
  return minutes;
}

async function login(req, res, next) {
  try {
    const { email, password } = req.body;
    const ip = req.ip;
    const ua = req.get('User-Agent');
    const user = await findUserByEmail(email);
    if (!user) {
      await db.query('INSERT INTO login_attempts(attempt_id, user_id, email_attempted, success, reason, ip_addr, user_agent) VALUES(gen_random_uuid(), NULL, $1, false, $2, $3, $4)', [email, 'not_found', ip, ua]);
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    // check lockout
    if (user.account_locked_until && new Date(user.account_locked_until) > new Date()) {
      await db.query('INSERT INTO login_attempts(attempt_id, user_id, email_attempted, success, reason, ip_addr, user_agent) VALUES(gen_random_uuid(), $1, $2, false, $3, $4, $5)', [user.user_id, email, 'locked', ip, ua]);
      return res.status(423).json({ error: 'Account locked. Try again later.' });
    }

    const ok = await bcrypt.compare(password, user.password_hash);
    if (!ok) {
      // increment failed count and maybe lock
      const failed = (user.failed_login_attempts || 0) + 1;
      let lockUntil = null;
      let lockCount = user.lock_count || 0;
      if (failed >= (parseInt(process.env.MAX_FAILED_ATTEMPTS || '5'))) {
        lockCount = (lockCount || 0) + 1;
        const minutes = computeLockMinutes(lockCount);
        lockUntil = new Date(Date.now() + minutes * 60 * 1000);
      }
      await db.query('UPDATE users SET failed_login_attempts=$1, lock_count=$2, account_locked_until=$3, last_failed_login=now() WHERE user_id=$4', [failed, lockCount, lockUntil, user.user_id]);
      await db.query('INSERT INTO login_attempts(attempt_id, user_id, email_attempted, success, reason, ip_addr, user_agent) VALUES(gen_random_uuid(), $1, $2, false, $3, $4, $5)', [user.user_id, email, 'invalid_password', ip, ua]);
      if (lockUntil) {
        // notify via email
        await sendEmail(user.email, 'Account locked', `<p>Your account was locked until ${lockUntil.toISOString()} due to failed login attempts.</p>`);
        return res.status(423).json({ error: 'Account locked due to repeated failed attempts.' });
      }
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    // success: reset counters
    await db.query('UPDATE users SET failed_login_attempts=0, lock_count=0, account_locked_until=NULL, last_login=now() WHERE user_id=$1', [user.user_id]);
    await db.query('INSERT INTO login_attempts(attempt_id, user_id, email_attempted, success, reason, ip_addr, user_agent) VALUES(gen_random_uuid(), $1, $2, true, $3, $4, $5)', [user.user_id, email, 'success', ip, ua]);

    // if email not verified, warn
    if (!user.is_verified) {
      return res.status(403).json({ error: 'Email not verified. Please verify your email.' });
    }

    // create session and optional JWT
    req.session.user = { user_id: user.user_id, email: user.email, role_id: user.role_id };
    const token = jwt.sign({ sub: user.user_id, email: user.email, role_id: user.role_id }, process.env.JWT_SECRET || 'dev-jwt', { expiresIn: '1d' });

    // respond with safe user
    res.json({ user: { email: user.email, name: user.full_name, role_id: user.role_id }, token });
  } catch (err) { next(err); }
}

async function logout(req, res, next) {
  req.session.destroy(err => {
    if (err) return next(err);
    res.json({ ok: true });
  });
}

async function verifyEmail(req, res, next) {
  try {
    const { token } = req.query;
    const { rows } = await db.query('SELECT * FROM email_verifications WHERE token=$1', [token]);
    const row = rows[0];
    if (!row) return res.status(400).json({ error: 'Invalid token' });
    if (new Date(row.expires_at) < new Date()) return res.status(400).json({ error: 'Token expired' });
    await db.query('UPDATE users SET is_verified = true WHERE user_id = $1', [row.user_id]);
    await db.query('DELETE FROM email_verifications WHERE token=$1', [token]);
    res.json({ ok: true, message: 'Email verified' });
  } catch (err) { next(err); }
}

module.exports = { register, login, logout, verifyEmail };


async function forgotPassword(req, res, next) {
  try {
    const { email } = req.body;
    const user = await findUserByEmail(email);
    // respond generically to avoid user enumeration
    if (!user) {
      return res.json({ message: 'If an account exists, reset instructions have been sent.' });
    }
    const token = uuidv4();
    const expires = new Date(Date.now() + 1000 * 60 * 60); // 1 hour
    await db.query('UPDATE users SET reset_token = $1, reset_token_expires = $2 WHERE user_id = $3', [token, expires, user.user_id]);
    const link = `${process.env.APP_BASE_URL || 'http://localhost:3000'}/reset-password?token=${token}`;
    await sendEmail(user.email, 'Password reset', `<p>Reset: <a href="${link}">${link}</a></p>`);
    return res.json({ message: 'If an account exists, reset instructions have been sent.' });
  } catch (err) { next(err); }
}

async function resetPassword(req, res, next) {
  try {
    const { token, new_password } = req.body;
    if (!token || !new_password) return res.status(400).json({ error: 'Missing token or password' });
    const { rows } = await db.query('SELECT * FROM users WHERE reset_token = $1 AND reset_token_expires > now()', [token]);
    const user = rows[0];
    if (!user) return res.status(400).json({ error: 'Invalid or expired token' });
    const hash = await bcrypt.hash(new_password, 10);
    await db.query('UPDATE users SET password_hash = $1, reset_token = NULL, reset_token_expires = NULL WHERE user_id = $2', [hash, user.user_id]);
    res.json({ message: 'Password reset successful' });
  } catch (err) { next(err); }
}

module.exports = Object.assign(module.exports || {}, { forgotPassword, resetPassword });


function me(req, res) {
  if (req.session && req.session.user) {
    res.json({ user: req.session.user });
  } else {
    res.status(401).json({ user: null });
  }
}

module.exports = Object.assign(module.exports || {}, { me });
