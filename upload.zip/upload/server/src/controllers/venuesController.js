const db = require('../utils/db');
const { v4: uuidv4 } = require('uuid');

async function listVenues(req, res, next) {
  try {
    const { q } = req.query;
    let where = [];
    const params = [];
    if (q) {
      params.push('%' + q + '%');
      where.push(`name ILIKE $${params.length}`);
    }
    const whereClause = where.length ? 'WHERE ' + where.join(' AND ') : '';
    const { rows } = await db.query(
      `SELECT venue_id, name, address, capacity, created_at FROM venues ${whereClause} ORDER BY created_at DESC LIMIT 100`,
      params
    );
    res.json(rows);
  } catch (err) {
    next(err);
  }
}

async function getVenue(req, res, next) {
  try {
    const { id } = req.params;
    const { rows } = await db.query(
      'SELECT venue_id, name, address, capacity, created_at FROM venues WHERE venue_id = $1',
      [id]
    );
    if (!rows[0]) return res.status(404).json({ error: 'Not found' });
    res.json(rows[0]);
  } catch (err) {
    next(err);
  }
}

async function createVenue(req, res, next) {
  try {
    const user = req.session.user;
    if (!user) return res.status(401).json({ error: 'Not authenticated' });
    const { name, address, capacity } = req.body;
    const { rows } = await db.query(
      'INSERT INTO venues(venue_id, name, address, capacity, created_at) VALUES($1, $2, $3, $4, now()) RETURNING *',
      [uuidv4(), name, address || {}, capacity || null]
    );
    res.status(201).json(rows[0]);
  } catch (err) {
    next(err);
  }
}

async function updateVenue(req, res, next) {
  try {
    const user = req.session.user;
    if (!user) return res.status(401).json({ error: 'Not authenticated' });
    const { id } = req.params;
    const { name, address, capacity } = req.body;
    const q = `UPDATE venues SET name = COALESCE($1, name), address = COALESCE($2, address), capacity = COALESCE($3, capacity) WHERE venue_id = $4 RETURNING *`;
    const params = [name || null, address || null, capacity || null, id];
    const { rows } = await db.query(q, params);
    if (!rows[0]) return res.status(404).json({ error: 'Not found' });
    res.json(rows[0]);
  } catch (err) {
    next(err);
  }
}

async function deleteVenue(req, res, next) {
  try {
    const user = req.session.user;
    if (!user) return res.status(401).json({ error: 'Not authenticated' });
    const { id } = req.params;
    await db.query('DELETE FROM venues WHERE venue_id = $1', [id]);
    res.json({ ok: true });
  } catch (err) {
    next(err);
  }
}

module.exports = { listVenues, getVenue, createVenue, updateVenue, deleteVenue };
