const db = require('../utils/db');
const redis = require('../utils/redis');
const { v4: uuidv4 } = require('uuid');

async function confirmReservation(req, res, next) {
  try {
    const user = req.session.user;
    if (!user) return res.status(401).json({ error: 'Not authenticated' });

    const { event_id, seat_ids, holder_name, price_cents } = req.body;
    if (!Array.isArray(seat_ids) || seat_ids.length === 0)
      return res.status(400).json({ error: 'No seats' });

    // Check seat locks
    for (const seat_id of seat_ids) {
      const key = `seatlock:${seat_id}`;
      const v = await redis.get(key);
      if (!v) return res.status(409).json({ error: `Seat ${seat_id} not locked` });
      const p = JSON.parse(v);
      if (p.user_id !== user.user_id)
        return res.status(403).json({ error: `Seat ${seat_id} locked by another` });
    }

    const expiresAt = new Date(Date.now() + 15 * 60 * 1000); // 15 min hold
    const { rows } = await db.query(
      'INSERT INTO ticket_reservations(reservation_id, user_id, event_id, status, expires_at) VALUES(gen_random_uuid(), $1, $2, $3, $4) RETURNING reservation_id, expires_at',
      [user.user_id, event_id || null, 'held', expiresAt]
    );
    const reservation = rows[0];

    const client = await db.pool.connect();
    try {
      await client.query('BEGIN');
      for (const seat_id of seat_ids) {
        const ticketCode = uuidv4();
        await client.query(
          'INSERT INTO tickets(ticket_id, reservation_id, seat_id, event_id, holder_name, price_cents, code) VALUES(gen_random_uuid(), $1, $2, $3, $4, $5, $6)',
          [
            reservation.reservation_id,
            seat_id,
            event_id || null,
            holder_name || null,
            price_cents || 0,
            ticketCode
          ]
        );
        await redis.del(`seatlock:${seat_id}`);
      }
      await client.query('COMMIT');
    } catch (e) {
      await client.query('ROLLBACK');
      throw e;
    } finally {
      client.release();
    }

    res.json({
      ok: true,
      reservation_id: reservation.reservation_id,
      expires_at: reservation.expires_at
    });
  } catch (e) {
    next(e);
  }
}

async function cancelReservation(req, res, next) {
  try {
    const { reservation_id } = req.body;
    const user = req.session.user;
    if (!user) return res.status(401).json({ error: 'Not authenticated' });

    await db.query(
      'UPDATE ticket_reservations SET status = $1 WHERE reservation_id = $2',
      ['expired', reservation_id]
    );
    res.json({ ok: true });
  } catch (e) {
    next(e);
  }
}

module.exports = { confirmReservation, cancelReservation };
