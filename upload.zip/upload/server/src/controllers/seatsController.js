const db = require('../utils/db');
const { v4: uuidv4 } = require('uuid');

// bulk create seats (array of seat objects)
async function bulkCreateSeats(req, res, next) {
  try {
    const { seats } = req.body;
    if (!Array.isArray(seats)) return res.status(400).json({ error: 'Bad request' });
    const client = await db.pool.connect();
    try {
      await client.query('BEGIN');
      const insertValues = seats.map((s, i) =>
        `($${i*9+1}, $${i*9+2}, $${i*9+3}, $${i*9+4}, $${i*9+5}, $${i*9+6}, $${i*9+7}, $${i*9+8}, $${i*9+9})`
      ).join(', ');
      // parameters: seat_id, section_id, row_label, seat_label, x, y, shape_json, status, tier_id
      const params = [];
      for (const s of seats) {
        params.push(
          uuidv4(), // seat_id
          s.section_id || null, // section_id as uuid
          s.row_label || null,
          s.seat_label || null,
          s.x || null,
          s.y || null,
          JSON.stringify(s.shape || {}),
          s.status || 'available',
          s.tier_id || null
        );
      }
      const q = `INSERT INTO seats(seat_id, section_id, row_label, seat_label, x, y, shape, status, tier_id) VALUES ${insertValues}`;
      await client.query(q, params);
      await client.query('COMMIT');
      res.json({ ok: true });
    } catch (err) {
      await client.query('ROLLBACK');
      throw err;
    } finally {
      client.release();
    }
  } catch (err) { next(err); }
}

async function updateSeat(req, res, next) {
  try {
    const { id } = req.params;
    const { section_id, row_label, seat_label, x, y, shape, status, tier_id } = req.body;
    const q = 'UPDATE seats SET section_id=COALESCE($1, section_id), row_label=COALESCE($2,row_label), seat_label=COALESCE($3,seat_label), x=COALESCE($4,x), y=COALESCE($5,y), shape=COALESCE($6,shape), status=COALESCE($7,status), tier_id=COALESCE($8,tier_id) WHERE seat_id=$9 RETURNING *';
    const params = [section_id || null, row_label || null, seat_label || null, x || null, y || null, shape || null, status || null, tier_id || null, id];
    const { rows } = await db.query(q, params);
    if (!rows[0]) return res.status(404).json({ error: 'Not found' });
    res.json(rows[0]);
  } catch (err) { next(err); }
}

// List seats by section
async function listSeatsBySection(req, res, next) {
  try {
    const { section_id } = req.params;
    const { rows } = await db.query('SELECT * FROM seats WHERE section_id = $1 ORDER BY row_label, seat_label', [section_id]);
    res.json(rows);
  } catch (err) { next(err); }
}

module.exports = { bulkCreateSeats, updateSeat, listSeatsBySection };
