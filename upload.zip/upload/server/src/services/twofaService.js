const speakeasy = require('speakeasy');
const qrcode = require('qrcode');

function generateSecret() {
  return speakeasy.generateSecret({ length: 20 });
}

function verifyTOTP(secret, token) {
  return speakeasy.totp.verify({ secret, encoding: 'base32', token, window: 1 });
}

async function toDataURL(otpauth_url) {
  return qrcode.toDataURL(otpauth_url);
}

module.exports = { generateSecret, verifyTOTP, toDataURL };
