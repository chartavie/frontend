function sanitizeSvg(svg){ if(!svg) return svg; svg = svg.replace(/<script[\s\S]*?>[\s\S]*?<\/script>/gi,''); svg = svg.replace(/\son[a-z]+=\"[^\"]*\"/gi,''); svg = svg.replace(/href=\"javascript:[^\"]*\"/gi,'href="#"'); return svg; }
module.exports = { sanitizeSvg };
