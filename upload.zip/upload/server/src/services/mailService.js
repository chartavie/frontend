const sgMail = require('@sendgrid/mail');
sgMail.setApiKey(process.env.SENDGRID_API_KEY || '');

async function sendEmail(to, subject, html) {
  if (!process.env.SENDGRID_API_KEY) {
    console.log('[mailService] SendGrid API key not configured. Email would be:', { to, subject, html });
    return;
  }
  const msg = { to, from: 'no-reply@ticketing.example.com', subject, html };
  await sgMail.send(msg);
}

module.exports = { sendEmail };
