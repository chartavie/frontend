-- Enable required PostgreSQL extensions
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE EXTENSION IF NOT EXISTS citext;

-- ============================
-- USERS & AUTH
-- ============================

CREATE TABLE IF NOT EXISTS users (
  user_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name text,
  email citext UNIQUE,
  password_hash text,
  phone text,
  is_verified boolean DEFAULT false,
  twofa_secret text,
  twofa_enabled boolean DEFAULT false,
  failed_login_attempts integer DEFAULT 0,
  lock_count integer DEFAULT 0,
  account_locked_until timestamptz NULL,
  last_failed_login timestamptz NULL,
  last_login timestamptz NULL,
  role_id uuid, -- Nullable in case of guest users
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS email_verifications (
  token text PRIMARY KEY,
  user_id uuid REFERENCES users(user_id) ON DELETE CASCADE,
  expires_at timestamptz NOT NULL
);

CREATE TABLE IF NOT EXISTS login_attempts (
  attempt_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NULL REFERENCES users(user_id),
  email_attempted text,
  success boolean NOT NULL,
  reason text,
  ip_addr text,
  user_agent text,
  created_at timestamptz DEFAULT now()
);

-- ============================
-- ROLES & PERMISSIONS
-- ============================

CREATE TABLE IF NOT EXISTS roles (
  role_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text,
  description text
);

CREATE TABLE IF NOT EXISTS permissions (
  perm_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text UNIQUE,
  description text
);

CREATE TABLE IF NOT EXISTS role_permissions (
  role_id uuid REFERENCES roles(role_id),
  perm_id uuid REFERENCES permissions(perm_id),
  PRIMARY KEY (role_id, perm_id)
);

-- ============================
-- VENUES & EVENTS
-- ============================

CREATE TABLE IF NOT EXISTS venues (
  venue_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  address jsonb,
  capacity integer,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS events (
  event_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NULL,
  title text NOT NULL,
  slug text UNIQUE,
  description text,
  category text,
  tags text[] DEFAULT '{}',
  venue_id uuid NULL REFERENCES venues(venue_id) ON DELETE SET NULL,
  start_time timestamptz,
  end_time timestamptz,
  status text NOT NULL DEFAULT 'draft', -- draft | published | archived
  poster_key text,
  created_by uuid,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);
ALTER TABLE events
  ADD COLUMN photo text,
  ADD COLUMN poster text,
  ADD COLUMN logo text;
CREATE INDEX IF NOT EXISTS idx_events_status_start ON events(status, start_time);

-- ============================
-- SEATMAPS, TIERS, SEATS
-- ============================

CREATE TABLE IF NOT EXISTS seatmaps (
  seatmap_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  venue_id uuid NOT NULL REFERENCES venues(venue_id) ON DELETE CASCADE,
  name text NOT NULL,
  type text NOT NULL DEFAULT 'reserved', -- reserved | general
  svg_content text,
  layout jsonb DEFAULT '{}', -- structure of sections, rows, seats, etc.
  created_by uuid,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS seating_tiers (
  tier_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  seatmap_id uuid NOT NULL REFERENCES seatmaps(seatmap_id) ON DELETE CASCADE,
  name text NOT NULL,
  price_cents integer NOT NULL DEFAULT 0,
  metadata jsonb DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS seats (
  seat_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  seatmap_id uuid NOT NULL REFERENCES seatmaps(seatmap_id) ON DELETE CASCADE,
  section_id uuid REFERENCES sections(section_id) ON DELETE SET NULL, -- updated: now references sections tableid REFERENCES sections(section_id) ON DELETE SET NULL, -- updated: now references sections table
  row_label text,
  seat_label text,
  x numeric,
  y numeric,
  shape jsonb, -- e.g., polygon or circle
  status text DEFAULT 'available', -- available, blocked, reserved
  tier_id uuid NULL REFERENCES seating_tiers(tier_id),
  metadata jsonb DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS sections (
  section_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  venue_id uuid NOT NULL REFERENCES venues(venue_id) ON DELETE CASCADE, -- add this line
  name text NOT NULL,
  row_count integer,
  col_count integer,
  x numeric,
  y numeric,
  metadata jsonb DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS nfc_mappings (
  mapping_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  seat_id uuid REFERENCES seats(seat_id) ON DELETE SET NULL,
  tag_uid text NOT NULL UNIQUE,
  created_by uuid,
  created_at timestamptz DEFAULT now()
);

-- ============================
-- RESERVATIONS & TICKETS
-- ============================

CREATE TABLE IF NOT EXISTS ticket_reservations (
  reservation_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NULL REFERENCES users(user_id),
  event_id uuid NULL REFERENCES events(event_id) ON DELETE SET NULL,
  status text NOT NULL DEFAULT 'held', -- held | confirmed | expired | cancelled
  expires_at timestamptz,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS tickets (
  ticket_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  reservation_id uuid REFERENCES ticket_reservations(reservation_id) ON DELETE CASCADE,
  seat_id uuid NULL REFERENCES seats(seat_id),
  event_id uuid NULL REFERENCES events(event_id),
  holder_name text,
  price_cents integer DEFAULT 0,
  code text UNIQUE,
  created_at timestamptz DEFAULT now()
);

-- ============================
-- SESSIONS
-- ============================

CREATE TABLE IF NOT EXISTS sessions (
  session_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(user_id) ON DELETE CASCADE,
  token text NOT NULL UNIQUE,
  ip_addr text,
  user_agent text,
  expires_at timestamptz NOT NULL,
  created_at timestamptz DEFAULT now(),
  revoked boolean DEFAULT false
);
