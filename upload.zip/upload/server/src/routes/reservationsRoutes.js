const express = require('express');
const router = express.Router();
const ctrl = require('../controllers/reservationsController');
router.post('/confirm', ctrl.confirmReservation);
router.post('/cancel', ctrl.cancelReservation);
module.exports = router;
