const express = require('express');
const router = express.Router();
const eventsCtrl = require('../controllers/eventsController');

// Remove csurf/csrfProtection from this file!
// CSRF protection should be applied at the app level only.

// public listing
router.get('/', eventsCtrl.listPublic);
router.get('/:id', eventsCtrl.getEvent);

// protected (create/update/delete) - CSRF protected and session required
router.post('/', eventsCtrl.createEvent);
router.put('/:id', eventsCtrl.updateEvent);
router.delete('/:id', eventsCtrl.deleteEvent);

module.exports = router;
