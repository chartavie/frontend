const express = require('express');
const router = express.Router();
const ctrl = require('../controllers/seatsController');

// List seats by section
router.get('/section/:section_id', ctrl.listSeatsBySection);

// Bulk create seats
router.post('/', ctrl.bulkCreateSeats);

// Update a seat
router.put('/:id', ctrl.updateSeat);

module.exports = router;
