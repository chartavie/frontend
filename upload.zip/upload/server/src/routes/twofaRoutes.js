const express = require('express');
const router = express.Router();
const twofaCtrl = require('../controllers/twofaController');
router.post('/setup', twofaCtrl.setup);
router.post('/verify', twofaCtrl.verify);
module.exports = router;
