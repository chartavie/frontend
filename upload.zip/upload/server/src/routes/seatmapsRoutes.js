const express = require('express');
const router = express.Router();
const ctrl = require('../controllers/seatmapsController');

// Remove csurf/csrfProtection from this file!
// CSRF protection should be applied at the app level only.

// If you want to provide the CSRF token to the client, do it in app.js, not here.

router.get('/', ctrl.listSeatmaps);
router.get('/:id', ctrl.getSeatmap);
router.post('/', ctrl.createSeatmap);
router.put('/:id', ctrl.updateSeatmap);
router.delete('/:id', ctrl.deleteSeatmap);

module.exports = router;
