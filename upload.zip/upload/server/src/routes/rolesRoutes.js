const express = require('express');
const router = express.Router();
const rolesCtrl = require('../controllers/rolesController');

// Remove csurf/csrfProtection from this file!
// CSRF protection should be applied at the app level only.

router.get('/', rolesCtrl.listRoles);
router.post('/', rolesCtrl.createRole);
router.delete('/:role_id', rolesCtrl.deleteRole);
router.get('/perms', rolesCtrl.listPerms);
router.post('/perms', rolesCtrl.createPerm);
router.delete('/perms/:perm_id', rolesCtrl.deletePerm);
router.put('/:role_id/permissions', rolesCtrl.replaceRolePermissions);

module.exports = router;
