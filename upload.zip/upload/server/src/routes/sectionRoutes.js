const express = require('express');
const router = express.Router();
const sectionController = require('../controllers/sectionController');

// List all sections for a seatmap
router.get('/seatmap/:seatmap_id', sectionController.listSections);

// List all sections for a venue
router.get('/venue/:venue_id', sectionController.listSections);

// Get a single section by ID
router.get('/:section_id', sectionController.getSection);

// Create a new section
router.post('/', sectionController.createSection);

// Update a section
router.put('/:section_id', sectionController.updateSection);

// Delete a section
router.delete('/:section_id', sectionController.deleteSection);

module.exports = router;