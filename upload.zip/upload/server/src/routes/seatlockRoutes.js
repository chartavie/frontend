const express = require('express');
const router = express.Router();
const ctrl = require('../controllers/seatlockController');
router.post('/lock', ctrl.lockSeat);
router.post('/unlock', ctrl.unlockSeat);
router.get('/status/:seat_id', ctrl.checkLock);
module.exports = router;
