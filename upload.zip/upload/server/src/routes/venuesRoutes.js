const express = require('express');
const router = express.Router();
const ctrl = require('../controllers/venuesController');
router.get('/', ctrl.listVenues);
router.get('/:id', ctrl.getVenue);
router.post('/', ctrl.createVenue);
router.put('/:id', ctrl.updateVenue);
router.delete('/:id', ctrl.deleteVenue);
module.exports = router;
