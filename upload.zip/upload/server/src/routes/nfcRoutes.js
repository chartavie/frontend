const express = require('express');
const router = express.Router();
const ctrl = require('../controllers/nfcController');
router.post('/', ctrl.createMapping);
router.get('/:tag_uid', ctrl.getMappingByTag);
module.exports = router;
