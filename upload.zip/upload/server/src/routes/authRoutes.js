const express = require('express');
const router = express.Router();
const authCtrl = require('../controllers/authController');

// Remove csurf/csrfProtection from this file!
// CSRF protection should be applied at the app level only.

router.post('/register', authCtrl.register);
router.post('/login', authCtrl.login);
router.post('/logout', authCtrl.logout);
router.post('/forgot-password', authCtrl.forgotPassword);
router.post('/reset-password', authCtrl.resetPassword);
router.get('/verify-email', authCtrl.verifyEmail);
router.get('/me', authCtrl.me);

module.exports = router;
