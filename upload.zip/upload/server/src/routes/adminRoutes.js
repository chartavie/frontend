const express = require('express');
const router = express.Router();
const db = require('../utils/db');

// list users (admin only in real app; here simplified)
router.get('/users', async (req, res, next) => {
  try {
    const { rows } = await db.query(
      'SELECT user_id, full_name, email, phone, failed_login_attempts, account_locked_until, is_verified FROM users ORDER BY created_at DESC'
    );
    res.json(rows);
  } catch (err) {
    next(err);
  }
});

router.post('/users/unlock', async (req, res, next) => {
  try {
    const { user_id } = req.body;
    await db.query(
      'UPDATE users SET failed_login_attempts = 0, account_locked_until = NULL, lock_count = 0 WHERE user_id = $1',
      [user_id]
    );
    res.json({ ok: true });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
