const express = require('express');
const router = express.Router();
const ctrl = require('../controllers/tiersController');
router.get('/', ctrl.listTiers);
router.post('/', ctrl.createTier);
router.put('/:id', ctrl.updateTier);
router.delete('/:id', ctrl.deleteTier);
module.exports = router;
