// src/app.js

const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const csurf = require('csurf');
const rateLimit = require('./middleware/rateLimitMiddleware');
const session = require('express-session');
const pgSession = require('connect-pg-simple')(session);
const cookieParser = require('cookie-parser');
const dotenv = require('dotenv');
dotenv.config();

const { pool } = require('./utils/db');
const authRoutes = require('./routes/authRoutes');
const twofaRoutes = require('./routes/twofaRoutes');
const adminRoutes = require('./routes/adminRoutes');
const rolesRoutes = require('./routes/rolesRoutes');
const eventsRoutes = require('./routes/eventsRoutes');
const venuesRoutes = require('./routes/venuesRoutes');
const nfcRoutes = require('./routes/nfcRoutes');
const reservationsRoutes = require('./routes/reservationsRoutes');
const seatlockRoutes = require('./routes/seatlockRoutes');
const seatmapsRoutes = require('./routes/seatmapsRoutes');
const tiersRoutes = require('./routes/tiersRoutes');
const sectionRoutes = require('./routes/sectionRoutes');

// Init express
const app = express();

// Environment
const isProd = process.env.NODE_ENV === 'production';
const DISABLE_CSRF = process.env.DISABLE_CSRF === 'true' || !isProd;
const CLIENT_ORIGIN = process.env.CLIENT_ORIGIN || 'http://localhost:3000';

// Middleware: security, parsing, and cookies
app.use(helmet());
app.use(express.json({ limit: '20mb' }));
app.use(express.urlencoded({ extended: true, limit: '20mb' }));
app.use(cookieParser());

// CORS
app.use(cors({
  origin: CLIENT_ORIGIN,
  credentials: true,
}));

// Sessions
app.use(session({
  store: new pgSession({ pool }),
  secret: process.env.SESSION_SECRET || 'change_this_session_secret',
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: isProd,
    httpOnly: true,
    sameSite: 'lax',
  }
}));

// CSRF protection (only enabled in production or when DISABLE_CSRF is false)
const csrfProtection = !DISABLE_CSRF ? csurf({ cookie: true }) : (req, res, next) => next();
if (DISABLE_CSRF) {
  console.warn('[dev] CSRF is DISABLED via DISABLE_CSRF=true or NODE_ENV!=production');
}

// CSRF Token endpoint
app.get('/api/csrf-token', csrfProtection, (req, res) => {
  if (DISABLE_CSRF) {
    // In dev, just return a dummy token
    res.json({ csrfToken: 'dev-csrf-not-required' });
  } else {
    const token = req.csrfToken();
    res
      .cookie('XSRF-TOKEN', token, {
        httpOnly: false,
        secure: isProd,
        sameSite: 'lax',
      })
      .json({ csrfToken: token });
  }
});

// Rate limiting
app.use('/api/auth/login', rateLimit.loginLimiter);
app.use('/api/auth/forgot-password', rateLimit.forgotLimiter);
app.use('/api/auth/register', rateLimit.registerLimiter);

// Protected Routes (CSRF applied conditionally)
app.use('/api/auth', csrfProtection, authRoutes);
app.use('/api/2fa', csrfProtection, twofaRoutes);
app.use('/api/admin', csrfProtection, adminRoutes);
app.use('/api/roles', csrfProtection, rolesRoutes);
app.use('/api/perms', csrfProtection, rolesRoutes);
app.use('/api/events', csrfProtection, eventsRoutes);
app.use('/api/venues', csrfProtection, venuesRoutes);
app.use('/api/nfc', csrfProtection, nfcRoutes);
app.use('/api/reservations', csrfProtection, reservationsRoutes);
app.use('/api/seatlocks', csrfProtection, seatlockRoutes);
app.use('/api/seatmaps', csrfProtection, seatmapsRoutes);
app.use('/api/tiers', csrfProtection, tiersRoutes);
app.use('/api/sections', csrfProtection, sectionRoutes);

// Health check (public)
app.get('/api/health', (req, res) => res.json({ ok: true }));

// Dev-only: seed user route
if (!isProd) {
  app.post('/dev/seed-user', express.json(), async (req, res, next) => {
    try {
      const { email = 'dev@example.com', name = 'Dev User', password = 'password' } = req.body || {};
      const bcrypt = require('bcryptjs');
      const hash = await bcrypt.hash(password, 10);
      const { rows } = await pool.query(
        `INSERT INTO users(full_name, email, password_hash, is_verified)
         VALUES($1, $2, $3, $4)
         ON CONFLICT (email) DO UPDATE SET password_hash = EXCLUDED.password_hash
         RETURNING user_id, email`,
        [name, email, hash, true]
      );
      res.json({ ok: true, user: rows[0] });
    } catch (err) {
      next(err);
    }
  });
}

// Global error handler (CSRF + others)
app.use((err, req, res, next) => {
  console.error('[ERROR]', err.stack || err);
  const status = err.status || 500;
  const message = err.code === 'EBADCSRFTOKEN'
    ? 'Invalid CSRF token'
    : err.message || 'Internal Server Error';
  res.status(status).json({ ok: false, error: message });
});

// Export for tests or server start
module.exports = app;

// Start server when run directly
if (require.main === module) {
  const PORT = Number(process.env.PORT || 5000);
  app.listen(PORT, () => {
    console.log(`API server listening on port ${PORT}`);
  });
}
