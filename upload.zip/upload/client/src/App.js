// src/App.js
import React, { useContext } from 'react';
import { BrowserRouter as Router, Routes, Route, Link, useLocation, Navigate } from 'react-router-dom';
import { ThemeProvider } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import Header from './components/Header';
import ProtectedRoute from './components/ProtectedRoute';
import { AuthContext } from './contexts/AuthContext';
import { ThemeContext } from './contexts/ThemeContext';

// Auth
import LoginForm from './components/LoginForm';
import RegisterForm from './components/RegisterForm';
import ForgotPassword from './components/ForgotPassword';
import ResetPassword from './components/ResetPassword';
import VerifyEmail from './components/VerifyEmail';
import TwoFAPrompt from './components/TwoFAPrompt';

// Admin & RBAC
import RBACMatrix from './components/RBACMatrix';

// Events
import EventList from './components/EventList';
import EventDetail from './components/EventDetail';
import EventForm from './components/EventForm';
import OrganizerDashboard from './components/OrganizerDashboard';

// Seatmap & Venues
import SeatmapDesigner from './components/SeatmapDesigner';
import SeatSelection from './components/SeatSelection';
import VenueForm from './components/VenueForm';
import VenueList from './components/VenueList';
import TierEditor from './components/TierEditor';
import VenueSectionSeatWorkflow from './components/VenueSectionSeatWorkflow';

function AppContent() {
  const location = useLocation();
  const hideHeader = ['/login', '/register'].includes(location.pathname);

  return (
    <>
      {!hideHeader && <Header />}

      <div style={{ padding: 16 }}>
        <Routes>
          {/* Auth (no header) */}
          <Route path="/login" element={<LoginForm />} />
          <Route path="/register" element={<RegisterForm />} />

          {/* Protected Routes */}
          <Route
            path="/"
            element={<ProtectedRoute><Navigate to="/dashboard" replace /></ProtectedRoute>}
          />
          <Route
            path="/dashboard"
            element={
              <ProtectedRoute>
                <OrganizerDashboard />
              </ProtectedRoute>
            }
          />
          <Route
            path="/forgot-password"
            element={<ForgotPassword />}
          />
          <Route
            path="/reset-password"
            element={<ResetPassword />}
          />
          <Route
            path="/verify-email"
            element={<VerifyEmail />}
          />
          <Route
            path="/2fa"
            element={<TwoFAPrompt />}
          />

          <Route
            path="/events"
            element={
              <ProtectedRoute>
                <EventList />
              </ProtectedRoute>
            }
          />
          <Route
            path="/events/new"
            element={
              <ProtectedRoute>
                <EventForm />
              </ProtectedRoute>
            }
          />
          <Route
            path="/events/:eventId"
            element={
              <ProtectedRoute>
                <EventDetail />
              </ProtectedRoute>
            }
          />

          <Route
            path="/venues"
            element={
              <ProtectedRoute>
                <VenueList />
              </ProtectedRoute>
            }
          />
          <Route
            path="/venues/new"
            element={
              <ProtectedRoute>
                <VenueForm />
              </ProtectedRoute>
            }
          />

          <Route
            path="/designer"
            element={
              <ProtectedRoute>
                <SeatmapDesigner />
              </ProtectedRoute>
            }
          />
          <Route
            path="/select"
            element={
              <ProtectedRoute>
                <SeatSelection />
              </ProtectedRoute>
            }
          />
          <Route
            path="/tiers"
            element={
              <ProtectedRoute>
                <TierEditor />
              </ProtectedRoute>
            }
          />

          <Route
            path="/workflow"
            element={
              <ProtectedRoute>
                <VenueSectionSeatWorkflow />
              </ProtectedRoute>
            }
          />

          <Route
            path="/rbac"
            element={
              <ProtectedRoute>
                <RBACMatrix />
              </ProtectedRoute>
            }
          />
        </Routes>
      </div>
    </>
  );
}

export default function App() {
  const { theme } = useContext(ThemeContext);

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Router>
        <AppContent />
      </Router>
    </ThemeProvider>
  );
}
