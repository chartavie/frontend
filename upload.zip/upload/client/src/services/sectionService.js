import { attachCsrf } from './csrf';

const API = process.env.REACT_APP_API_URL || 'http://localhost:5000';
const API_PREFIX = API.endsWith('/api') ? API : API + '/api';

export async function fetchSections(venueId, csrfToken) {
  const res = await fetch(`${API_PREFIX}/sections/venue/${venueId}`, {
    credentials: 'include',
    headers: attachCsrf({}, csrfToken)
  });
  if (!res.ok) throw await res.json();
  return res.json();
}

export async function fetchSection(sectionId, csrfToken) {
  const res = await fetch(`${API_PREFIX}/sections/${sectionId}`, {
    credentials: 'include',
    headers: attachCsrf({}, csrfToken)
  });
  if (!res.ok) throw await res.json();
  return res.json();
}

export async function createSection(data, csrfToken) {
  const res = await fetch(`${API_PREFIX}/sections`, {
    method: 'POST',
    headers: attachCsrf({ 'Content-Type':'application/json' }, csrfToken),
    credentials: 'include',
    body: JSON.stringify(data)
  });
  if (!res.ok) throw await res.json();
  return res.json();
}

export async function updateSection(sectionId, data, csrfToken) {
  const res = await fetch(`${API_PREFIX}/sections/${sectionId}`, {
    method: 'PUT',
    headers: attachCsrf({ 'Content-Type':'application/json' }, csrfToken),
    credentials: 'include',
    body: JSON.stringify(data)
  });
  if (!res.ok) throw await res.json();
  return res.json();
}

export async function deleteSection(sectionId, csrfToken) {
  const res = await fetch(`${API_PREFIX}/sections/${sectionId}`, {
    method: 'DELETE',
    headers: attachCsrf({}, csrfToken),
    credentials: 'include'
  });
  if (!res.ok) throw await res.json();
  return res.json();
}