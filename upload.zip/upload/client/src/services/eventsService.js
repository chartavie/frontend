import { attachCsrf } from './csrf';

const API = process.env.REACT_APP_API_URL || 'http://localhost:5000';

export async function fetchEvents(query = '') {
  const res = await fetch(`${API}/api/events${query ? '?'+query : ''}`, { credentials: 'include' });
  if (!res.ok) throw new Error('Failed to fetch events');
  return res.json();
}

export async function fetchEvent(id) {
  const res = await fetch(`${API}/api/events/${id}`, { credentials: 'include' });
  if (!res.ok) throw new Error('Not found');
  return res.json();
}

export async function createEvent(data, csrfToken) {
  const res = await fetch(`${API}/api/events`, {
    method: 'POST',
    headers: attachCsrf({ 'Content-Type': 'application/json' }, csrfToken),
    body: JSON.stringify(data),
    credentials: 'include'
  });
  if (!res.ok) throw await res.json();
  return res.json();
}

export async function updateEvent(id, data, csrfToken) {
  const res = await fetch(`${API}/api/events/${id}`, {
    method: 'PUT',
    headers: attachCsrf({ 'Content-Type': 'application/json' }, csrfToken),
    body: JSON.stringify(data),
    credentials: 'include'
  });
  if (!res.ok) throw await res.json();
  return res.json();
}

export async function deleteEvent(id, csrfToken) {
  const res = await fetch(`${API}/api/events/${id}`, {
    method: 'DELETE',
    headers: attachCsrf({}, csrfToken),
    credentials: 'include'
  });
  if (!res.ok) throw await res.json();
  return res.json();
}
