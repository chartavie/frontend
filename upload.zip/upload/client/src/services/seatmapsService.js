import { attachCsrf } from './csrf';

const API = process.env.REACT_APP_API_URL || 'http://localhost:5000';
const API_PREFIX = API.endsWith('/api') ? API : API + '/api';

export async function fetchSeatmaps(venueId, csrfToken) {
  const qs = venueId ? '?venue_id=' + venueId : '';
  const res = await fetch(`${API_PREFIX}/seatmaps${qs}`, {
    credentials: 'include',
    headers: attachCsrf({}, csrfToken)
  });
  if (!res.ok) throw await res.json();
  return res.json();
}

export async function fetchSeatmap(id, csrfToken) {
  const res = await fetch(`${API_PREFIX}/seatmaps/${id}`, {
    credentials: 'include',
    headers: attachCsrf({}, csrfToken)
  });
  if (!res.ok) throw await res.json();
  return res.json();
}

export async function saveSeatmap(data, csrfToken) {
  const res = await fetch(`${API_PREFIX}/seatmaps`, {
    method: 'POST',
    headers: attachCsrf({ 'Content-Type':'application/json' }, csrfToken),
    credentials: 'include',
    body: JSON.stringify(data)
  });
  if (!res.ok) throw await res.json();
  return res.json();
}

export async function updateSeatmap(id, data, csrfToken) {
  const res = await fetch(`${API_PREFIX}/seatmaps/${id}`, {
    method: 'PUT',
    headers: attachCsrf({ 'Content-Type':'application/json' }, csrfToken),
    credentials: 'include',
    body: JSON.stringify(data)
  });
  if (!res.ok) throw await res.json();
  return res.json();
}

export async function listSeats(seatmapId, csrfToken) {
  const res = await fetch(`${API_PREFIX}/seats/${seatmapId}`, {
    credentials: 'include',
    headers: attachCsrf({}, csrfToken)
  });
  if (!res.ok) throw await res.json();
  return res.json();
}

export async function bulkCreateSeats(payload, csrfToken) {
  const res = await fetch(`${API_PREFIX}/seats`, {
    method: 'POST',
    headers: attachCsrf({ 'Content-Type':'application/json' }, csrfToken),
    credentials: 'include',
    body: JSON.stringify(payload)
  });
  if (!res.ok) throw await res.json();
  return res.json();
}

export async function updateSeat(id, data, csrfToken) {
  const res = await fetch(`${API_PREFIX}/seats/${id}`, {
    method: 'PUT',
    headers: attachCsrf({ 'Content-Type':'application/json' }, csrfToken),
    credentials: 'include',
    body: JSON.stringify(data)
  });
  if (!res.ok) throw await res.json();
  return res.json();
}
