import { attachCsrf } from './csrf';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000';

export async function fetchVenues() {
  const res = await fetch(`${API_URL}/api/venues`, { credentials: 'include' });
  if (!res.ok) throw new Error('Failed to fetch venues');
  return res.json();
}

export async function createVenue(data, csrfToken) {
  const res = await fetch(`${API_URL}/api/venues`, {
    method: 'POST',
    credentials: 'include',
    headers: attachCsrf({ 'Content-Type': 'application/json' }, csrfToken),
    body: JSON.stringify(data)
  });
  if (!res.ok) throw new Error('Failed to create venue');
  return res.json();
}

export async function updateVenue(id, data, csrfToken) {
  const res = await fetch(`${API_URL}/api/venues/${id}`, {
    method: 'PUT',
    credentials: 'include',
    headers: attachCsrf({ 'Content-Type': 'application/json' }, csrfToken),
    body: JSON.stringify(data)
  });
  if (!res.ok) throw new Error('Failed to update venue');
  return res.json();
}

export async function deleteVenue(id, csrfToken) {
  const res = await fetch(`${API_URL}/api/venues/${id}`, {
    method: 'DELETE',
    credentials: 'include',
    headers: attachCsrf({}, csrfToken)
  });
  if (!res.ok) throw new Error('Failed to delete venue');
  return res.json();
}