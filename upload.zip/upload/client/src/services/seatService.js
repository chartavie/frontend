import { attachCsrf } from './csrf';

const API = process.env.REACT_APP_API_URL || 'http://localhost:5000';
const API_PREFIX = API.endsWith('/api') ? API : API + '/api';

export async function listSeatsBySection(sectionId, csrfToken) {
  const res = await fetch(`${API_PREFIX}/seats/section/${sectionId}`, {
    credentials: 'include',
    headers: attachCsrf({}, csrfToken)
  });
  if (!res.ok) throw await res.json();
  return res.json();
}

export async function bulkCreateSeats(seats, csrfToken) {
  const res = await fetch(`${API_PREFIX}/seats`, {
    method: 'POST',
    headers: attachCsrf({ 'Content-Type':'application/json' }, csrfToken),
    credentials: 'include',
    body: JSON.stringify({ seats })
  });
  if (!res.ok) throw await res.json();
  return res.json();
}

export async function updateSeat(id, data, csrfToken) {
  const res = await fetch(`${API_PREFIX}/seats/${id}`, {
    method: 'PUT',
    headers: attachCsrf({ 'Content-Type':'application/json' }, csrfToken),
    credentials: 'include',
    body: JSON.stringify(data)
  });
  if (!res.ok) throw await res.json();
  return res.json();
}

