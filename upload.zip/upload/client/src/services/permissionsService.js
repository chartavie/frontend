// src/services/permissionsService.js
import { attachCsrf } from './csrf';

const API = process.env.REACT_APP_API_URL || 'http://localhost:5000'; 

export async function createPermission(name, description, csrfToken) {
  const res = await fetch(`${API}/api/perms`, {
    method:'POST',
    headers: attachCsrf({ 'Content-Type':'application/json' }, csrfToken),
    body: JSON.stringify({ name, description }),
    credentials: 'include'
  });
  return res.json();
}

export async function deletePermission(permId, csrfToken) {
  const res = await fetch(`${API}/api/perms/${permId}`, {
    method: 'DELETE',
    headers: attachCsrf({}, csrfToken),
    credentials: 'include'
  });
  return res.json();
}

export async function createRole(name, description, csrfToken) {
  const res = await fetch(`${API}/api/roles`, {
    method:'POST',
    headers: attachCsrf({ 'Content-Type':'application/json' }, csrfToken),
    body: JSON.stringify({ name, description }),
    credentials: 'include'
  });
  return res.json();
}

export async function deleteRole(roleId, csrfToken) {
  const res = await fetch(`${API}/api/roles/${roleId}`, {
    method: 'DELETE',
    headers: attachCsrf({}, csrfToken),
    credentials: 'include'
  });
  return res.json();
}
