import { attachCsrf } from './csrf';

const API = process.env.REACT_APP_API_URL || 'http://localhost:5000'; 

export async function fetchRoles(csrfToken) {
  const res = await fetch(`${API}/api/roles`, {
    headers: attachCsrf({}, csrfToken),
    credentials: 'include'
  });
  if (!res.ok) throw await res.json();
  return res.json();
}

export async function fetchPerms(csrfToken) {
  const res = await fetch(`${API}/api/perms`, {
    headers: attachCsrf({}, csrfToken),
    credentials: 'include'
  });
  if (!res.ok) throw await res.json();
  return res.json();
}

export async function updateRolePerms(roleId, permIds = [], csrfToken) {
  const res = await fetch(`${API}/api/roles/${roleId}/perms`, {
    method: 'PUT',
    credentials: 'include',
    headers: attachCsrf({ 'Content-Type': 'application/json' }, csrfToken),
    body: JSON.stringify({ perm_ids: permIds })
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: 'Request failed' }));
    throw new Error(err.error || res.statusText);
  }
  return res.json();
}
