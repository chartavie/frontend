// src/services/csrf.js
const rawApi = process.env.REACT_APP_API_URL || 'http://localhost:5000';
// remove trailing '/api' or trailing slash if present
const API = rawApi.replace(/\/api\/?$/i, '').replace(/\/$/, '');

export async function getCsrfToken() {
  const res = await fetch(`${API}/api/csrf-token`, { credentials: 'include' });
  if (!res.ok) throw new Error('Failed to fetch CSRF token');
  const j = await res.json();
  return j.csrfToken || '';
}

// Only attach if not the dummy dev token
export function attachCsrf(headers = {}, token) {
  if (token && token !== 'dev-csrf-not-required') headers['x-csrf-token'] = token;
  return headers;
}
