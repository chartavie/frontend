import React, { useEffect, useState } from 'react';
import { Card, Paper, List, ListItem, Button } from '@mui/material';
import { fetchRoles, fetchPerms, updateRolePerms } from '../services/rbacService';

import PermissionsManager from './PermissionsManager';
import RoleCreator from './RoleCreator';

const API = process.env.REACT_APP_API_URL || 'http://localhost:5000';

export default function RBACMatrix() {
  const [roles, setRoles] = useState([]);
  const [perms, setPerms] = useState([]);
  const [csrf, setCsrf] = useState('');
  const [loadingRole, setLoadingRole] = useState(null);

  useEffect(() => {
    // fetch CSRF token first
    (async () => {
      try {
        const res = await fetch(`${API}/api/csrf-token`, { credentials: 'include' });
        if (!res.ok) throw new Error('Failed to fetch CSRF token');
        const d = await res.json();
        setCsrf(d.csrfToken || '');
      } catch (err) {
        console.error('Failed to load CSRF token', err);
      }
    })();
  }, []);

  useEffect(() => {
    if (!csrf) return;
    Promise.all([fetchRoles(csrf), fetchPerms(csrf)]).then(([r, p]) => {
      setRoles(r);
      setPerms(p);
    }).catch(err => {
      console.error('Failed to load RBAC data', err);
    });
  }, [csrf]);

  async function toggle(role, perm) {
    setLoadingRole(role.role_id);
    try {
      const has = (role.perms || []).some(p => p.perm_id === perm.perm_id);
      const newPerms = has
        ? (role.perms || []).filter(p => p.perm_id !== perm.perm_id).map(p => p.perm_id)
        : [...(role.perms || []).map(p => p.perm_id), perm.perm_id];

      await updateRolePerms(role.role_id, newPerms, csrf);

      // refresh
      const [r, p] = await Promise.all([fetchRoles(csrf), fetchPerms(csrf)]);
      setRoles(r); setPerms(p);
    } catch (err) {
      console.error('Failed to update role perms', err);
      // optionally show UI feedback here
    } finally {
      setLoadingRole(null);
    }
  }

  return (
    <div>
      <RoleCreator />
      <PermissionsManager />

      <Card style={{ padding: 12, maxWidth: 900, margin: '20px auto' }}>
        <h3>RBAC Matrix</h3>
        <Paper style={{ padding: 8 }}>
          <List>
            {roles.map(role => (
              <ListItem key={role.role_id} style={{ flexDirection: 'column', alignItems: 'flex-start' }}>
                <div style={{ fontWeight: 600 }}>{role.name}</div>
                <div style={{ width: '100%' }}>
                  {perms.map(perm => {
                    const assigned = (role.perms || []).some(p => p.perm_id === perm.perm_id);
                    return (
                      <Paper
                        key={perm.perm_id}
                        style={{ padding: 8, marginTop: 8, display: 'flex', justifyContent: 'space-between' }}
                        elevation={1}
                      >
                        <div>
                          <div style={{ fontWeight: 500 }}>{perm.name}</div>
                          <div style={{ color: '#666' }}>{perm.description}</div>
                        </div>
                        <div>
                          <Button
                            onClick={() => toggle(role, perm)}
                            disabled={Boolean(loadingRole) && loadingRole !== role.role_id}
                          >
                            {assigned ? '✓ Assigned' : 'Assign'}
                          </Button>
                        </div>
                      </Paper>
                    );
                  })}
                </div>
              </ListItem>
            ))}
          </List>
        </Paper>
      </Card>
    </div>
  );
}
