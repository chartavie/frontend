import React, { useState, useEffect } from 'react';
import {
  Dialog, DialogTitle, DialogContent, DialogActions, Paper, List, ListItem,
  TextField, Button, Autocomplete, Avatar, IconButton, Chip, Tooltip, Typography, Box
} from '@mui/material';
import { createEvent, updateEvent, fetchEvent } from '../services/eventsService';
import { getCsrfToken } from '../services/csrf';
import { fetchVenues } from '../services/venueService';
import { format, parseISO } from 'date-fns';
import CloseIcon from '@mui/icons-material/Close';
import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css';
import AddToCalendarButton from '@culturehq/add-to-calendar';

export default function EventForm({ open, onClose, eventId }) {
  const [csrf, setCsrf] = useState('');
  const [form, setForm] = useState({
    title: '', description: '', category: '', tags: [],
    start_time: '', end_time: '', venue_id: '',
    photo: '', poster: '', logo: ''
  });
  const [venues, setVenues] = useState([]);
  const [preview, setPreview] = useState({ photo: '', poster: '', logo: '' });
  const [tagInput, setTagInput] = useState('');
  const [errors, setErrors] = useState({});
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    getCsrfToken().then(setCsrf);
    fetchVenues().then(setVenues);
    if (eventId) {
      fetchEvent(eventId).then(e => setForm(f => ({
        ...f,
        ...e,
        start_time: e.start_time ? format(parseISO(e.start_time), "yyyy-MM-dd'T'HH:mm") : '',
        end_time: e.end_time ? format(parseISO(e.end_time), "yyyy-MM-dd'T'HH:mm") : '',
        photo: e.photo || '',
        poster: e.poster || '',
        logo: e.logo || ''
      })));
    }
  }, [eventId]);

  function handleFileChange(field, e) {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = ev => {
      setForm(prev => ({ ...prev, [field]: ev.target.result }));
      setPreview(prev => ({ ...prev, [field]: ev.target.result }));
    };
    reader.readAsDataURL(file);
  }

  function handleRemoveImage(field) {
    setForm(prev => ({ ...prev, [field]: '' }));
    setPreview(prev => ({ ...prev, [field]: '' }));
  }

  function handleTagDelete(tagToDelete) {
    setForm(prev => ({ ...prev, tags: prev.tags.filter(tag => tag !== tagToDelete) }));
  }

  function validate() {
    const errs = {};
    if (!form.title) errs.title = 'Title is required';
    if (!form.venue_id) errs.venue_id = 'Venue is required';
    if (!form.start_time) errs.start_time = 'Start time is required';
    if (!form.end_time) errs.end_time = 'End time is required';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  }

  async function submit(e) {
    e.preventDefault();
    if (!validate()) return;
    setSubmitting(true);
    const data = {
      ...form,
      start_time: form.start_time ? new Date(form.start_time).toISOString() : '',
      end_time: form.end_time ? new Date(form.end_time).toISOString() : ''
    };
    try {
      if (eventId) {
        await updateEvent(eventId, data, csrf);
      } else {
        await createEvent(data, csrf);
      }
      if (onClose) onClose();
    } finally {
      setSubmitting(false);
    }
  }

  // Prepare event data for AddToCalendarButton
  const isValidDate = d => {
    if (!d) return false;
    const date = new Date(d);
    return !isNaN(date.getTime());
  };

  const calendarEvent = {
    name: form.title || "Event",
    details: typeof form.description === 'string'
      ? form.description.replace(/<[^>]+>/g, '')
      : '',
    location: venues.find(v => v.venue_id === form.venue_id)?.name || '',
    startsAt: isValidDate(form.start_time) ? new Date(form.start_time).toISOString() : undefined,
    endsAt: isValidDate(form.end_time) ? new Date(form.end_time).toISOString() : undefined,
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle>
        {eventId ? 'Edit Event' : 'Create Event'}
      </DialogTitle>
      <DialogContent>
        <Paper style={{ padding: 16 }}>
          <form onSubmit={submit}>
            <List>
              <ListItem>
                <TextField
                  label="Title"
                  fullWidth
                  value={form.title}
                  onChange={e => setForm({ ...form, title: e.target.value })}
                  error={!!errors.title}
                  helperText={errors.title}
                  required
                />
              </ListItem>
              <ListItem>
                <TextField
                  label="Category"
                  fullWidth
                  value={form.category}
                  onChange={e => setForm({ ...form, category: e.target.value })}
                />
              </ListItem>
              <ListItem>
                <TextField
                  label="Start"
                  type="datetime-local"
                  fullWidth
                  value={form.start_time}
                  onChange={e => setForm({ ...form, start_time: e.target.value })}
                  InputLabelProps={{ shrink: true }}
                  error={!!errors.start_time}
                  helperText={errors.start_time}
                  required
                />
              </ListItem>
              <ListItem>
                <TextField
                  label="End"
                  type="datetime-local"
                  fullWidth
                  value={form.end_time}
                  onChange={e => setForm({ ...form, end_time: e.target.value })}
                  InputLabelProps={{ shrink: true }}
                  error={!!errors.end_time}
                  helperText={errors.end_time}
                  required
                />
              </ListItem>
              <ListItem>
                <Autocomplete
                  options={venues}
                  getOptionLabel={option => option.name || ''}
                  value={venues.find(v => v.venue_id === form.venue_id) || null}
                  onChange={(_, value) => setForm({ ...form, venue_id: value ? value.venue_id : '' })}
                  renderInput={params => (
                    <TextField
                      {...params}
                      label="Venue"
                      fullWidth
                      error={!!errors.venue_id}
                      helperText={errors.venue_id}
                      required
                    />
                  )}
                />
              </ListItem>
              <ListItem>
                <Autocomplete
                  multiple
                  freeSolo
                  options={[]}
                  value={form.tags}
                  inputValue={tagInput}
                  onInputChange={(_, value) => setTagInput(value)}
                  onChange={(_, value) => setForm({ ...form, tags: value })}
                  renderTags={(value, getTagProps) =>
                    value.map((option, index) => (
                      <Chip
                        variant="outlined"
                        label={option}
                        {...getTagProps({ index })}
                        onDelete={() => handleTagDelete(option)}
                      />
                    ))
                  }
                  renderInput={params => (
                    <TextField {...params} label="Tags" placeholder="Add tag" fullWidth />
                  )}
                />
              </ListItem>
              <ListItem>
                <Box width="100%">
                  <Typography variant="subtitle1" gutterBottom>Description</Typography>
                  <ReactQuill
                    theme="snow"
                    value={form.description}
                    onChange={val => setForm({ ...form, description: val })}
                    style={{ width: '100%', minHeight: 120, background: '#fff' }}
                  />
                </Box>
              </ListItem>
              <ListItem>
                <Tooltip title="Upload a photo for the event (square recommended)">
                  <Button variant="outlined" component="label" sx={{ mr: 2 }}>
                    Upload Photo
                    <input type="file" accept="image/*" hidden onChange={e => handleFileChange('photo', e)} />
                  </Button>
                </Tooltip>
                {form.photo && (
                  <>
                    <Avatar src={form.photo} alt="Photo" sx={{ width: 56, height: 56, marginLeft: 2 }} />
                    <IconButton onClick={() => handleRemoveImage('photo')} size="small"><CloseIcon /></IconButton>
                  </>
                )}
              </ListItem>
              <ListItem>
                <Tooltip title="Upload a poster for the event (vertical recommended)">
                  <Button variant="outlined" component="label" sx={{ mr: 2 }}>
                    Upload Poster
                    <input type="file" accept="image/*" hidden onChange={e => handleFileChange('poster', e)} />
                  </Button>
                </Tooltip>
                {form.poster && (
                  <>
                    <img src={form.poster} alt="Poster" style={{ width: 80, height: 80, objectFit: 'cover', marginLeft: 8 }} />
                    <IconButton onClick={() => handleRemoveImage('poster')} size="small"><CloseIcon /></IconButton>
                  </>
                )}
              </ListItem>
              <ListItem>
                <Tooltip title="Upload a logo for the event or organizer">
                  <Button variant="outlined" component="label" sx={{ mr: 2 }}>
                    Upload Logo
                    <input type="file" accept="image/*" hidden onChange={e => handleFileChange('logo', e)} />
                  </Button>
                </Tooltip>
                {form.logo && (
                  <>
                    <Avatar src={form.logo} alt="Logo" sx={{ width: 56, height: 56, marginLeft: 2 }} />
                    <IconButton onClick={() => handleRemoveImage('logo')} size="small"><CloseIcon /></IconButton>
                  </>
                )}
              </ListItem>
              <ListItem>
                {isValidDate(form.start_time) && isValidDate(form.end_time) ? (
                  <AddToCalendarButton
                    event={calendarEvent}
                    buttonText="Add to Calendar"
                    buttonTemplate={{ google: "Google", outlook: "Outlook", yahoo: "Yahoo", ical: "iCal" }}
                  />
                ) : (
                  <Typography color="textSecondary" variant="body2">
                    Fill in valid start and end date/time to enable calendar export.
                  </Typography>
                )}
              </ListItem>
            </List>
          </form>
        </Paper>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose} disabled={submitting}>Cancel</Button>
        <Button variant="contained" onClick={submit} disabled={submitting}>
          {submitting ? "Saving..." : "Save"}
        </Button>
      </DialogActions>
    </Dialog>
  );
}
