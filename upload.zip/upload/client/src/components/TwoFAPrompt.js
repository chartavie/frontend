import React, { useState } from 'react';
import { Card, Paper, List, ListItem, TextField, Button } from '@mui/material';
import { getCsrfToken } from '../services/csrf'; // added

export default function TwoFAPrompt() {
  const [token, setToken] = useState('');
  const [msg, setMsg] = useState('');
  const [loading, setLoading] = useState(false);

  async function submit() {
    setLoading(true);
    setMsg('');
    try {
      const rawApi = process.env.REACT_APP_API_URL || 'http://localhost:5000';
      const API = rawApi.replace(/\/api\/?$/i, '').replace(/\/$/, '');
      const csrf = await getCsrfToken();

      const res = await fetch(`${API}/api/2fa/verify`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-csrf-token': csrf
        },
        body: JSON.stringify({ token }),
        credentials: 'include'
      });

      const data = await res.json().catch(() => ({}));
      if (res.ok && data.ok) {
        setMsg('2FA verified');
        // optionally redirect or update auth state here
      } else {
        // show server-provided error (e.g. "Email not verified...")
        setMsg(data.error || data.message || 'Verification failed');
      }
    } catch (err) {
      console.error('2FA verify error', err);
      setMsg(err.message || 'Network error');
    } finally {
      setLoading(false);
    }
  }

  return (
    <Card style={{ maxWidth:420, margin:'20px auto', padding:16 }}>
      <Paper style={{ padding:12 }}>
        <List>
          <ListItem>
            <TextField
              label="2FA Token"
              fullWidth
              value={token}
              onChange={e => setToken(e.target.value)}
            />
          </ListItem>
          <ListItem>
            <Button onClick={submit} variant="contained" disabled={loading}>
              {loading ? 'Verifying...' : 'Verify'}
            </Button>
          </ListItem>
          <ListItem>{msg}</ListItem>
        </List>
      </Paper>
    </Card>
  );
}
