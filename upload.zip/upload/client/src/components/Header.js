import React, { useContext } from 'react';
import { Link } from 'react-router-dom';
import { AppBar, Toolbar, Typography, IconButton, Button, List, ListItem } from '@mui/material';
import { ThemeContext } from '../contexts/ThemeContext';
import { AuthContext } from '../contexts/AuthContext';
import Brightness4Icon from '@mui/icons-material/Brightness4';
import Brightness7Icon from '@mui/icons-material/Brightness7';

export default function Header() {
  const { mode, toggleTheme } = useContext(ThemeContext);
  const { user, logout } = useContext(AuthContext);

  return (
    <AppBar position="static">
      <Toolbar style={{ display: 'flex', justifyContent: 'space-between' }}>
        <Typography component={Link} to="/" style={{ color: 'white', textDecoration: 'none', fontWeight: 600 }}>
          Ticketing
        </Typography>
        <div style={{ display: 'flex', alignItems: 'center' }}>
          {/* Navigation Links: only show if logged in */}
          {user && (
            <List style={{ display: 'flex' }}>
              <ListItem disablePadding>
                <Button color="inherit" component={Link} to="/designer">Designer</Button>
              </ListItem>
              <ListItem disablePadding>
                <Button color="inherit" component={Link} to="/venues">Venues</Button>
              </ListItem>
              <ListItem disablePadding>
                <Button color="inherit" component={Link} to="/events">Events</Button>
              </ListItem>
              <ListItem disablePadding>
                <Button color="inherit" component={Link} to="/rbac">RBAC</Button>
              </ListItem>
              <ListItem disablePadding>
                <Button color="inherit" component={Link} to="/workflow">Workflow</Button>
              </ListItem>
            </List>
          )}
          {/* Theme Toggle */}
          <IconButton color="inherit" onClick={toggleTheme}>
            {mode === 'light' ? <Brightness4Icon /> : <Brightness7Icon />}
          </IconButton>
          {/* Auth Buttons */}
          <List style={{ display: 'flex' }}>
            {!user ? (
              <>
                <ListItem disablePadding>
                  <Button color="inherit" component={Link} to="/login">Login</Button>
                </ListItem>
                <ListItem disablePadding>
                  <Button color="inherit" component={Link} to="/register">Register</Button>
                </ListItem>
              </>
            ) : (
              <ListItem disablePadding>
                <Button color="inherit" onClick={logout}>Logout</Button>
              </ListItem>
            )}
          </List>
        </div>
      </Toolbar>
    </AppBar>
  );
}
