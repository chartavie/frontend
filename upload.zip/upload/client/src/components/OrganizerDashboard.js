import React from 'react';
import { Card, Paper, List, ListItem, Button } from '@mui/material';
import EventList from './EventList';
import { Link } from 'react-router-dom';

export default function OrganizerDashboard() {
  return (
    <div style={{ padding:20 }}>
      <Card style={{ padding:12, maxWidth:1000, margin:'0 auto 20px' }}>
        <h3>Organizer Dashboard</h3>
        <Paper style={{ padding:8 }}>
          <List>
            <ListItem><Button component={Link} to="/events/new">Create Event</Button></ListItem>
            <ListItem><Button component={Link} to="/rbac">Manage Roles & Permissions</Button></ListItem>
          </List>
        </Paper>
      </Card>
      <EventList />
    </div>
  );
}
