import React, { useState, useEffect } from 'react';
import { Card, Paper, List, ListItem, TextField, Button } from '@mui/material';
import { getCsrfToken } from '../services/csrf';
import { createRole, deleteRole } from '../services/permissionsService';
import { fetchRoles } from '../services/rbacService';

export default function RoleCreator() {
  const [name, setName] = useState('');
  const [desc, setDesc] = useState('');
  const [roles, setRoles] = useState([]);
  const [csrf, setCsrf] = useState('');

  useEffect(()=>{ getCsrfToken().then(setCsrf); }, []);
  useEffect(()=>{ if(csrf) fetchRoles(csrf).then(setRoles); }, [csrf]);

  async function add() {
    await createRole(name, desc, csrf);
    setName(''); setDesc('');
    const r = await fetchRoles(csrf); setRoles(r);
  }
  async function remove(id) {
    await deleteRole(id, csrf);
    const r = await fetchRoles(csrf); setRoles(r);
  }

  return (
    <Card style={{ padding:12, maxWidth:800, margin:'20px auto' }}>
      <h3>Roles</h3>
      <Paper style={{ padding:8 }}>
        <List>
          <ListItem><TextField label="Role name" value={name} onChange={e=>setName(e.target.value)} /></ListItem>
          <ListItem><TextField label="Description" value={desc} onChange={e=>setDesc(e.target.value)} /></ListItem>
          <ListItem><Button onClick={add} variant="contained">Create Role</Button></ListItem>
        </List>
        <div style={{ marginTop:12 }}>
          {roles.map(r => (
            <Paper key={r.role_id} style={{ padding:8, marginTop:8, display:'flex', justifyContent:'space-between' }}>
              <div><strong>{r.name}</strong><div style={{color:'#666'}}>{r.description}</div></div>
              <div><Button onClick={()=>remove(r.role_id)}>Delete</Button></div>
            </Paper>
          ))}
        </div>
      </Paper>
    </Card>
  );
}
