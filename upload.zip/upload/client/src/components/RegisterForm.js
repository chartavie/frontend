import { getCsrfToken } from '../services/csrf';
import React, { useState } from 'react';
import { Card, Paper, List, ListItem, TextField, Button } from '@mui/material';

export default function RegisterForm() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setLoading(true);
    try {
      const csrfToken = await getCsrfToken();
      const rawApi = process.env.REACT_APP_API_URL || 'http://localhost:5000';
      const API = rawApi.replace(/\/api\/?$/i, '').replace(/\/$/, '');
      const headers = { 'Content-Type': 'application/json' };
      if (csrfToken && csrfToken !== 'dev-csrf-not-required') {
        headers['x-csrf-token'] = csrfToken;
      }
      const res = await fetch(`${API}/api/auth/register`, {
        method: 'POST',
        credentials: 'include', 
        headers,
        body: JSON.stringify({ name, email, password })
      });

      const data = await res.json().catch(()=>({}));
      if (!res.ok) {
        const msg = data.error || data.message || res.statusText || 'Registration failed';
        alert(msg);
      } else {
        alert(data.message || 'Registered successfully');
      }
    } catch (err) {
      console.error('Register error', err);
      alert(err.message || 'Registration error');
    } finally {
      setLoading(false);
    }
  }

  return (
    <Card style={{ maxWidth:420, margin:'20px auto', padding:16 }}>
      <Paper style={{ padding:12 }}>
        <form onSubmit={submit}>
          <List>
            <ListItem>
              <TextField label="Full name" fullWidth value={name} onChange={e=>setName(e.target.value)} required />
            </ListItem>
            <ListItem>
              <TextField label="Email" fullWidth value={email} onChange={e=>setEmail(e.target.value)} required />
            </ListItem>
            <ListItem>
              <TextField label="Password" type="password" fullWidth value={password} onChange={e=>setPassword(e.target.value)} required />
            </ListItem>
            <ListItem>
              <Button type="submit" variant="contained" disabled={loading}>
                {loading ? 'Registering...' : 'Register'}
              </Button>
            </ListItem>
          </List>
        </form>
      </Paper>
    </Card>
  );
}
