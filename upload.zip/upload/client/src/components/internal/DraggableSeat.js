// client/src/components/DraggableSeat.jsx
import React, { useRef, useEffect } from 'react';

/**
 * SVG-based seat component.
 * Props:
 *  - seat: { seat_id, x, y, row_label, seat_label, shape:{type,r}, seat_type_id, tier_id, color }
 *  - selected: boolean
 *  - highlighted: boolean
 *  - zoom: number
 *  - onPointerDown(seat, clientX, clientY)
 *  - onClick(seat)
 *  - onDoubleClick(seat)
 */
export default function DraggableSeat({
  seat,
  selected = false,
  highlighted = false,
  zoom = 1,
  onPointerDown,
  onClick,
  onDoubleClick
}) {
  const gRef = useRef(null);

  useEffect(() => {
    const el = gRef.current;
    if (!el) return;
    // ensure pointer events pass through text; handled on group
    return () => {};
  }, []);

  const r = (seat.shape && seat.shape.r) ? seat.shape.r : 10;
  const fill = seat.color || (seat.tier_color || '#90caf9');
  const stroke = highlighted ? '#ff1744' : (selected ? '#2e7d32' : '#1565c0');
  const strokeWidth = selected ? 3 : 1.6;

  function handlePointerDown(e) {
    // prevent parent pan capturing immediately
    e.stopPropagation();
    e.preventDefault();
    onPointerDown && onPointerDown(seat, e.clientX, e.clientY);
  }

  function handleClick(e){
    e.stopPropagation();
    e.preventDefault();
    onClick && onClick(seat);
  }

  function handleDbl(e){
    e.stopPropagation();
    e.preventDefault();
    onDoubleClick && onDoubleClick(seat);
  }

  // position group at 0,0 and use transform for easier pointer math in parent
  return (
    <g
      ref={gRef}
      transform={`translate(${seat.x},${seat.y}) scale(${zoom})`}
      style={{ cursor: 'pointer', touchAction: 'none' }}
      onPointerDown={handlePointerDown}
      onClick={handleClick}
      onDoubleClick={handleDbl}
    >
      {seat.shape && seat.shape.type === 'rect' ? (
        <rect x={-r} y={-r} width={r*2} height={r*2} rx={Math.max(2, r/3)}
          fill={fill} stroke={stroke} strokeWidth={strokeWidth} />
      ) : (
        <circle r={r} fill={fill} stroke={stroke} strokeWidth={strokeWidth} />
      )}
      <text x={0} y={0} textAnchor="middle" dominantBaseline="central" fontSize={Math.max(9, r-2)} fill="#fff" pointerEvents="none">
        {(seat.row_label || '') + (seat.seat_label || '')}
      </text>
    </g>
  );
}
