import React, { useState } from 'react';
import { Dialog, DialogTitle, DialogContent, DialogActions, List, ListItem, TextField, Button } from '@mui/material';
import { createSection } from '../services/sectionService';

export default function SectionForm({ open, onClose, venue, onCreated }) {
  const [name, setName] = useState('');
  const [rowCount, setRowCount] = useState(10);
  const [colCount, setColCount] = useState(10);
  const [x, setX] = useState(100);
  const [y, setY] = useState(100);
  const [error, setError] = useState('');

  async function submit() {
    if (!name || !venue?.venue_id) {
      setError('Section name and venue are required.');
      return;
    }
    try {
      const section = {
        venue_id: venue.venue_id,
        name,
        row_count: Number(rowCount),
        col_count: Number(colCount),
        x: Number(x),
        y: Number(y),
        metadata: {}
      };
      const createdSection = await createSection(section);
      setError('');
      alert('Section created');
      if (onCreated) onCreated(createdSection);
      if (onClose) onClose(createdSection);
    } catch (e) {
      setError(e?.message || 'Failed to create section');
    }
  }

  return (
    <Dialog open={open} onClose={() => onClose && onClose(null)} maxWidth="sm" fullWidth>
      <DialogTitle>Add Section for {venue?.name}</DialogTitle>
      <DialogContent>
        <List>
          <ListItem>
            <TextField label="Section Name" value={name} onChange={e => setName(e.target.value)} fullWidth />
          </ListItem>
          <ListItem>
            <TextField label="Rows" type="number" value={rowCount} onChange={e => setRowCount(e.target.value)} fullWidth />
          </ListItem>
          <ListItem>
            <TextField label="Columns" type="number" value={colCount} onChange={e => setColCount(e.target.value)} fullWidth />
          </ListItem>
          <ListItem>
            <TextField label="X Position" type="number" value={x} onChange={e => setX(e.target.value)} fullWidth />
          </ListItem>
          <ListItem>
            <TextField label="Y Position" type="number" value={y} onChange={e => setY(e.target.value)} fullWidth />
          </ListItem>
          {error && (
            <ListItem>
              <span style={{ color: 'red' }}>{error}</span>
            </ListItem>
          )}
        </List>
      </DialogContent>
      <DialogActions>
        <Button onClick={() => onClose && onClose(null)}>Cancel</Button>
        <Button onClick={submit} variant="contained">Add Section</Button>
      </DialogActions>
    </Dialog>
  );
}