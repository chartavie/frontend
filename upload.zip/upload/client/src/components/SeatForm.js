import React, { useState } from 'react';
import { Dialog, DialogTitle, DialogContent, DialogActions, List, ListItem, TextField, Button } from '@mui/material';
import { bulkCreateSeats } from '../services/seatmapsService';

export default function SeatForm({ open, onClose, section }) {
  const [rowCount, setRowCount] = useState(section?.row_count || 10);
  const [colCount, setColCount] = useState(section?.col_count || 10);
  const [error, setError] = useState('');

  async function submit() {
    if (!section?.section_id) {
      setError('Section is required.');
      return;
    }
    try {
      // Generate seats for the section
      const seats = [];
      for (let r = 0; r < rowCount; r++) {
        for (let c = 0; c < colCount; c++) {
          seats.push({
            section_id: section.section_id,
            row_label: String.fromCharCode(65 + r),
            seat_label: (c + 1).toString(),
            x: section.x + c * 32,
            y: section.y + r * 32,
            shape: { type: 'circle', r: 10 },
            status: 'available',
            tier_id: null
          });
        }
      }
      await bulkCreateSeats({ seats });
      setError('');
      alert('Seats created');
      if (onClose) onClose();
    } catch (e) {
      setError(e?.message || 'Failed to create seats');
    }
  }

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
      <DialogTitle>Add Seats for Section {section?.name}</DialogTitle>
      <DialogContent>
        <List>
          <ListItem>
            <TextField label="Rows" type="number" value={rowCount} onChange={e => setRowCount(Number(e.target.value))} fullWidth />
          </ListItem>
          <ListItem>
            <TextField label="Columns" type="number" value={colCount} onChange={e => setColCount(Number(e.target.value))} fullWidth />
          </ListItem>
          {error && (
            <ListItem>
              <span style={{ color: 'red' }}>{error}</span>
            </ListItem>
          )}
        </List>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Cancel</Button>
        <Button onClick={submit} variant="contained">Add Seats</Button>
      </DialogActions>
    </Dialog>
  );
}