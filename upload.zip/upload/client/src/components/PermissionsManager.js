import React, { useEffect, useState } from 'react';
import { Card, Paper, List, ListItem, TextField, Button } from '@mui/material';
import { fetchPerms } from '../services/rbacService';
import { createPermission, deletePermission } from '../services/permissionsService';
import { getCsrfToken } from '../services/csrf';

export default function PermissionsManager() {
  const [perms, setPerms] = useState([]);
  const [name, setName] = useState('');
  const [desc, setDesc] = useState('');
  const [csrf, setCsrf] = useState('');

  useEffect(() => {
    getCsrfToken().then(t => setCsrf(t));
  }, []);

  useEffect(() => {
    if (!csrf) return;
    fetchPerms(csrf).then(setPerms);
  }, [csrf]);

  async function add() {
    await createPermission(name, desc, csrf);
    setName(''); setDesc('');
    const p = await fetchPerms(csrf); setPerms(p);
  }

  async function remove(id) {
    await deletePermission(id, csrf);
    const p = await fetchPerms(csrf); setPerms(p);
  }

  return (
    <Card style={{ padding:12, maxWidth:800, margin:'20px auto' }}>
      <h3>Permissions</h3>
      <Paper style={{ padding:8 }}>
        <List>
          <ListItem><TextField label="Name" value={name} onChange={e=>setName(e.target.value)} /></ListItem>
          <ListItem><TextField label="Description" value={desc} onChange={e=>setDesc(e.target.value)} /></ListItem>
          <ListItem><Button onClick={add} variant="contained">Create Permission</Button></ListItem>
        </List>
        <div style={{ marginTop:12 }}>
          {perms.map(p => (
            <Paper key={p.perm_id} style={{ padding:8, marginTop:8, display:'flex', justifyContent:'space-between' }}>
              <div><strong>{p.name}</strong><div style={{color:'#666'}}>{p.description}</div></div>
              <div><Button onClick={()=>remove(p.perm_id)}>Delete</Button></div>
            </Paper>
          ))}
        </div>
      </Paper>
    </Card>
  );
}
