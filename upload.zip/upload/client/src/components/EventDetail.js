import React, { useEffect, useState } from 'react';
import { Card, Paper, List, ListItem, Button } from '@mui/material';
import { fetchEvent } from '../services/eventsService';
import { useParams, Link } from 'react-router-dom';

export default function EventDetail() {
  const { id } = useParams();
  const [event, setEvent] = useState(null);
  useEffect(()=>{ fetchEvent(id).then(setEvent).catch(()=>setEvent(null)); }, [id]);
  if (!event) return <Card style={{ padding:12, maxWidth:800, margin:'20px auto' }}><Paper style={{ padding:8 }}><div>Event not found</div></Paper></Card>;
  return (
    <Card style={{ padding:12, maxWidth:800, margin:'20px auto' }}>
      <h3>{event.title}</h3>
      <Paper style={{ padding:8 }}>
        <List>
          <ListItem>{event.description}</ListItem>
          <ListItem>Category: {event.category}</ListItem>
          <ListItem>Start: {new Date(event.start_time).toLocaleString()}</ListItem>
          <ListItem>End: {event.end_time ? new Date(event.end_time).toLocaleString() : '—'}</ListItem>
          <ListItem><Button component={Link} to="/">Back</Button></ListItem>
        </List>
      </Paper>
    </Card>
  );
}
