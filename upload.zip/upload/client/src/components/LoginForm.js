import { getCsrfToken } from '../services/csrf';
import React, { useState, useContext } from 'react';
import { Card, Paper, List, ListItem, TextField, Button } from '@mui/material';
import { AuthContext } from '../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';

export default function LoginForm() {
  const { login } = useContext(AuthContext);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  async function submit(e) {
    e.preventDefault();
    try {
      const csrfToken = await getCsrfToken();

      const API = (process.env.REACT_APP_API_URL || 'http://localhost:5000').replace(/\/api\/?$/i, '').replace(/\/$/, '');
      const headers = { 'Content-Type': 'application/json' };
      if (csrfToken && csrfToken !== 'dev-csrf-not-required') {
        headers['x-csrf-token'] = csrfToken;
      }

      const res = await fetch(`${API}/api/auth/login`, {
        method: 'POST',
        headers,
        body: JSON.stringify({ email, password }),
        credentials: 'include'
      });

      const data = await res.json().catch(() => ({}));
      if (res.ok) {
        login(data.user, data.token);
        navigate('/dashboard'); 
      } else {
        alert(data.error || data.message || 'Login failed');
      }
    } catch (err) {
      console.error('Login error', err);
      alert(err.message || 'Login error');
    }
  }

  return (
    <Card style={{ maxWidth:420, margin:'20px auto', padding:16 }}>
      <Paper style={{ padding:12 }}>
        <form onSubmit={submit}>
          <List>
            <ListItem><TextField label="Email" fullWidth value={email} onChange={e=>setEmail(e.target.value)} /></ListItem>
            <ListItem><TextField label="Password" type="password" fullWidth value={password} onChange={e=>setPassword(e.target.value)} /></ListItem>
            <ListItem><Button type="submit" variant="contained">Login</Button></ListItem>
          </List>
        </form>
      </Paper>
    </Card>
  );
}
