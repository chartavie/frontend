import { getCsrfToken } from '../services/csrf';
import React, { useState } from 'react';
import { Card, Paper, List, ListItem, TextField, Button } from '@mui/material';

export default function ResetPassword() {
  const [token, setToken] = useState('');
  const [password, setPassword] = useState('');
  const [msg, setMsg] = useState('');
  async function submit() {
    const csrfToken = await getCsrfToken();
            const res = await fetch((process.env.REACT_APP_API_URL||'http://localhost:5000') + '/api/auth/reset-password', { headers: { 'X-CSRF-Token': csrfToken, 'Content-Type':'application/json' },
      method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ token, new_password: password })
    });
    const data = await res.json();
    setMsg(data.message || data.error || JSON.stringify(data));
  }
  return (
    <Card style={{ maxWidth:420, margin:'20px auto', padding:16 }}>
      <Paper style={{ padding:12 }}>
        <List>
          <ListItem><TextField label="Reset token" fullWidth value={token} onChange={e=>setToken(e.target.value)} /></ListItem>
          <ListItem><TextField label="New password" type="password" fullWidth value={password} onChange={e=>setPassword(e.target.value)} /></ListItem>
          <ListItem><Button onClick={submit} variant="contained">Reset</Button></ListItem>
          <ListItem>{msg}</ListItem>
        </List>
      </Paper>
    </Card>
  );
}
