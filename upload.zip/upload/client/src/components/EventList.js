import React, { useEffect, useState } from 'react';
import { Card, Paper, List, ListItem, Button } from '@mui/material';
import { fetchEvents } from '../services/eventsService';
import { Link } from 'react-router-dom';
import EventForm from './EventForm';

export default function EventList() {
  const [events, setEvents] = useState([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [editId, setEditId] = useState(null);

  function openAddModal() {
    setEditId(null);
    setModalOpen(true);
  }

  function openEditModal(eventId) {
    setEditId(eventId);
    setModalOpen(true);
  }

  function handleClose() {
    setModalOpen(false);
    setEditId(null);
    fetchEvents().then(setEvents); 
  }

  useEffect(() => {
    fetchEvents()
      .then(setEvents)
      .catch(console.error);
  }, []);

  return (
    <Card style={{ padding: 12, maxWidth: 1000, margin: '20px auto' }}>
      <h3 style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        Upcoming Events
        <Button variant="contained" onClick={openAddModal}>Add Event</Button>
      </h3>
      <Paper style={{ padding: 8 }}>
        <List>
          {events.map(event => (
            <div key={event.event_id}>
              <h3>{event.title}</h3>
              {event.photo && <img src={event.photo} alt="Event" style={{ maxWidth: 200 }} />}
              {event.poster && <img src={event.poster} alt="Poster" style={{ maxWidth: 200 }} />}
              {event.logo && <img src={event.logo} alt="Logo" style={{ maxWidth: 100 }} />}
              <div style={{ color: '#666' }}>{event.category} • {new Date(event.start_time).toLocaleString()}</div>
              <Button component={Link} to={'/events/' + event.event_id}>View</Button>
              <Button onClick={() => openEditModal(event.event_id)} style={{ marginLeft: 8 }}>Edit</Button>
            </div>
          ))}
        </List>
      </Paper>
      <EventForm open={modalOpen} onClose={handleClose} eventId={editId} />
    </Card>
  );
}
