import React, { useEffect, useState } from 'react';
import { Card, Paper, List, ListItem, Button } from '@mui/material';
import VenueForm from './VenueForm';
import { fetchVenues } from '../services/venueService';

export default function VenueList() {
  const [venues, setVenues] = useState([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [editVenue, setEditVenue] = useState(null);

  useEffect(() => {
    fetchVenues().then(setVenues).catch(console.error);
  }, []);

  function openAddModal() {
    setEditVenue(null);
    setModalOpen(true);
  }

  function openEditModal(venue) {
    setEditVenue(venue);
    setModalOpen(true);
  }

  function handleClose() {
    setModalOpen(false);
    setEditVenue(null);
    fetchVenues().then(setVenues).catch(console.error);
  }

  return (
    <Card style={{ padding: 12, maxWidth: 900, margin: '20px auto' }}>
      <h3 style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        Venues
        <Button variant="contained" onClick={openAddModal}>Add Venue</Button>
      </h3>
      <Paper style={{ padding: 8 }}>
        <List>
          {venues.map(v => (
            <ListItem key={v.venue_id} style={{ display: 'flex', justifyContent: 'space-between' }}>
              <div>
                <strong>{v.name}</strong>
                <div style={{ color: '#666' }}>{v.capacity} seats</div>
              </div>
              <div>
                <Button href={'/designer'}>Open</Button>
                <Button style={{ marginLeft: 8 }} onClick={() => openEditModal(v)}>Edit</Button>
              </div>
            </ListItem>
          ))}
        </List>
      </Paper>
      <VenueForm open={modalOpen} onClose={handleClose} venue={editVenue} />
    </Card>
  );
}
