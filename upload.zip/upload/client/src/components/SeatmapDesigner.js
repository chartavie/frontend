// client/src/components/SeatmapDesigner.jsx
import React, { useEffect, useRef, useState, useCallback } from 'react';
import {
  Card, Paper, ListItem, Button, TextField, Autocomplete, IconButton,
  Box, Typography, Divider, Grid, MenuItem, Select, FormControl, InputLabel
} from '@mui/material';
import UploadIcon from '@mui/icons-material/UploadFile';
import DownloadIcon from '@mui/icons-material/Download';
import UndoIcon from '@mui/icons-material/Undo';
import RedoIcon from '@mui/icons-material/Redo';
import ZoomInIcon from '@mui/icons-material/ZoomIn';
import ZoomOutIcon from '@mui/icons-material/ZoomOut';
import ContentCopyIcon from '@mui/icons-material/ContentCopy';
import SaveIcon from '@mui/icons-material/Save';
import DraggableSeat from './internal/DraggableSeat';
import { fetchVenues } from '../services/venueService';
import { fetchSeatmaps, fetchSeatmap, saveSeatmap, updateSeatmap } from '../services/seatmapsService';

// Helper
function debounce(fn, wait=50){ let t; return (...args)=>{ clearTimeout(t); t=setTimeout(()=>fn(...args), wait); }; }
function guid(prefix='s'){ return prefix + '_' + Math.random().toString(36).slice(2,9); }

// Basic mapping of seat types to default color (can be extended)
const DEFAULT_SEAT_TYPES = [
  { seat_type_id: 'standard', label: 'Standard', color: '#1e88e5', default_price_cents: 10000, description: 'Standard seat for general admission.' },
  { seat_type_id: 'vip', label: 'VIP', color: '#d32f2f', default_price_cents: 25000, description: 'Premium seat for VIP guests.' },
  { seat_type_id: 'accessible', label: 'Accessible', color: '#43a047', default_price_cents: 9000, description: 'Accessible seat for guests with disabilities.' },
  { seat_type_id: 'companion', label: 'Companion', color: '#fb8c00', default_price_cents: 0, description: 'Companion seat for accessible guests.' },
  { seat_type_id: 'standing', label: 'Standing', color: '#6a1b9a', default_price_cents: 5000, description: 'Standing area.' },
  { seat_type_id: 'couch', label: 'Lounge', color: '#8e24aa', default_price_cents: 30000, description: 'Lounge or couch seating.' },
  { seat_type_id: 'table_banquet', label: 'Banquet Table', color: '#fbc02d', default_price_cents: 0, description: 'Round tables with 8-10 guests per table. Best for social events, wedding receptions, and formal dinners.' },
  { seat_type_id: 'theater', label: 'Theater Style', color: '#1976d2', default_price_cents: 0, description: 'Rows of chairs facing a stage. Best for lectures and performances.' },
  { seat_type_id: 'classroom', label: 'Classroom Style', color: '#388e3c', default_price_cents: 0, description: 'Tables in rows with chairs on one side. Best for conferences and training.' },
  { seat_type_id: 'boardroom', label: 'Boardroom Style', color: '#6d4c41', default_price_cents: 0, description: 'Single rectangular table with participants around it. Best for small meetings.' },
  { seat_type_id: 'cabaret', label: 'Cabaret Style', color: '#e57373', default_price_cents: 0, description: 'Semi-circle of chairs around small tables. Best for award ceremonies and presentations.' },
  { seat_type_id: 'cocktail', label: 'Cocktail Style', color: '#00bcd4', default_price_cents: 0, description: 'High-top tables with limited seating. Encourages mingling.' },
  { seat_type_id: 'u_shape', label: 'U-Shape', color: '#7b1fa2', default_price_cents: 0, description: 'Tables arranged in a "U" with chairs on the outside. Best for interaction with a facilitator.' },
  { seat_type_id: 'hollow_square', label: 'Hollow Square', color: '#c62828', default_price_cents: 0, description: 'Square or rectangular table with center open. Best for collaboration.' },
  { seat_type_id: 'herringbone', label: 'Herringbone', color: '#2e7d32', default_price_cents: 0, description: 'Chairs angled in rows for clear view and space.' },
  { seat_type_id: 'bar', label: 'Bar', color: '#ff9800', default_price_cents: 0, description: 'Bar seating.' },
  { seat_type_id: 'open_space', label: 'Open Space', color: '#bdbdbd', default_price_cents: 0, description: 'Open area for flexible arrangements.' }
];

// Templates generator: returns a layout object { seats: [ ... ] , sections: [...] }
function generateTemplate(type, cfg = {}) {
  const seats = [];

  if (type === 'theater' || type === 'opera') {
    // semicircular rows facing stage at top center
    const rows = cfg.rows || 12;
    const baseRadius = cfg.baseRadius || 220;
    const centerX = cfg.width/2 || 800/2;
    const centerY = cfg.topOffset || 120;
    for (let r=0;r<rows;r++){
      const radius = baseRadius + r*32;
      const seatsInRow = Math.max(6, Math.round((rows - r) * 3 + 10));
      for (let s=0;s<seatsInRow;s++){
        const angle = Math.PI*(1 + (s/(seatsInRow-1))*-1); // left->right semicircle
        const x = centerX + Math.cos(angle) * radius;
        const y = centerY + Math.sin(angle) * radius;
        seats.push({
          seat_id: guid('t'),
          x, y,
          row_label: String.fromCharCode(65 + r),
          seat_label: String(s+1),
          shape: { type: 'circle', r: 10 },
          seat_type_id: r < 2 ? 'vip' : 'standard',
          tier: r < 2 ? 'VIP' : 'Standard'
        });
      }
    }
    return { seats, sections: [{ id: 'stage', label: 'Stage', type: 'stage' }] };
  }

  if (type === 'stadium') {
    // rings of seats around center
    const rings = cfg.rings || 6;
    const centerX = cfg.width/2 || 800/2;
    const centerY = cfg.height/2 || 600/2;
    for (let ring=0; ring<rings; ring++){
      const rows = 10 + ring*6;
      const radius = 60 + ring*40;
      for (let i=0;i<rows;i++){
        const angle = (i/rows) * Math.PI*2;
        seats.push({
          seat_id: guid('st'),
          x: centerX + Math.cos(angle)*radius,
          y: centerY + Math.sin(angle)*radius,
          row_label: (ring+1).toString(),
          seat_label: (i+1).toString(),
          shape: { type: 'circle', r: 8 },
          seat_type_id: 'standard',
          tier: ring===0 ? 'Premium' : ring<3 ? 'Standard' : 'Economy'
        });
      }
    }
    return { seats, sections: [] };
  }

  if (type === 'plane') {
    // simple forward-facing rows with aisles
    const rows = cfg.rows || 30;
    const cols = cfg.cols || 6; // typical 3-aisle-3 -> we will place an aisle between col 3 and 4
    const startX = 80, startY=60, xSpacing=48, ySpacing=36;
    for (let r=0;r<rows;r++){
      for (let c=0;c<cols;c++){
        const seatIndex = r*cols + c;
        const x = startX + c * xSpacing + (c >= 3 ? 20 : 0); // small aisle
        const y = startY + r * ySpacing;
        seats.push({
          seat_id: guid('p'),
          x, y,
          row_label: String(r+1),
          seat_label: String.fromCharCode(65 + c),
          shape: { type: 'rect', r: 6 },
          seat_type_id: (r<2 ? 'vip' : 'standard'),
          tier: r<2 ? 'First' : 'Economy'
        });
      }
    }
    return { seats, sections: [] };
  }

  if (type === 'bus') {
    // two columns + aisle
    const rows = cfg.rows || 12;
    const startX = 80, startY = 60, xSpacing = 90, ySpacing = 48;
    for (let r = 0; r < rows; r++){
      for (let side=0; side<2; side++){
        const x = startX + side * xSpacing;
        const y = startY + r * ySpacing;
        seats.push({
          seat_id: guid('b'),
          x,y,
          row_label: String(r+1),
          seat_label: side===0 ? 'A' : 'B',
          shape: { type: 'rect', r: 6 },
          seat_type_id: 'standard',
          tier: 'Coach'
        });
      }
    }
    return { seats, sections: [] };
  }

  if (type === 'banquet') {
    // round tables with chairs
    const tablesX = cfg.tablesX || 4, tablesY = cfg.tablesY || 3;
    const startX = 120, startY = 100, xSpacing = 220, ySpacing = 180;
    for (let ty=0; ty<tablesY; ty++){
      for (let tx=0; tx<tablesX; tx++){
        const cx = startX + tx * xSpacing;
        const cy = startY + ty * ySpacing;
        const chairs = cfg.chairsPerTable || 8;
        const radius = 48;
        for (let k=0;k<chairs;k++){
          const angle = (k / chairs) * (Math.PI*2);
          seats.push({
            seat_id: guid('bn'),
            x: cx + Math.cos(angle)*radius,
            y: cy + Math.sin(angle)*radius,
            row_label: 'T'+(ty*tablesX+tx+1),
            seat_label: String(k+1),
            shape: { type: 'circle', r: 10 },
            seat_type_id: 'standard',
            tier: 'Banquet'
          });
        }
      }
    }
    return { seats, sections: [] };
  }

  if (type === 'open') {
    // open floor with nomadic seating (no seats by default)
    return { seats: [], sections: [] };
  }

  if (type === 'table_banquet' || type === 'table') {
    // Single round table with 10 seats
    const cx = cfg.cx || 400, cy = cfg.cy || 300, chairs = 10, radius = 60;
    for (let k = 0; k < chairs; k++) {
      const angle = (k / chairs) * (Math.PI * 2);
      seats.push({
        seat_id: guid('tb'),
        x: cx + Math.cos(angle) * radius,
        y: cy + Math.sin(angle) * radius,
        row_label: 'T1',
        seat_label: String(k + 1),
        shape: { type: 'circle', r: 12 },
        seat_type_id: 'table_banquet',
        tier: 'Banquet'
      });
    }
    return { seats, sections: [] };
  }

  if (type === 'u_shape') {
    // U-shaped arrangement
    const rows = 5, cols = 8, startX = 120, startY = 120, spacing = 48;
    // left vertical
    for (let r = 0; r < rows; r++) {
      seats.push({
        seat_id: guid('u'),
        x: startX,
        y: startY + r * spacing,
        row_label: 'U',
        seat_label: String(r + 1),
        shape: { type: 'rect', r: 10 },
        seat_type_id: 'u_shape',
        tier: 'Standard'
      });
    }
    // bottom horizontal
    for (let c = 1; c < cols - 1; c++) {
      seats.push({
        seat_id: guid('u'),
        x: startX + c * spacing,
        y: startY + (rows - 1) * spacing,
        row_label: 'U',
        seat_label: String(rows + c),
        shape: { type: 'rect', r: 10 },
        seat_type_id: 'u_shape',
        tier: 'Standard'
      });
    }
    // right vertical
    for (let r = 0; r < rows; r++) {
      seats.push({
        seat_id: guid('u'),
        x: startX + (cols - 1) * spacing,
        y: startY + r * spacing,
        row_label: 'U',
        seat_label: String(rows + cols - 2 + r + 1),
        shape: { type: 'rect', r: 10 },
        seat_type_id: 'u_shape',
        tier: 'Standard'
      });
    }
    return { seats, sections: [] };
  }

  if (type === 'boardroom') {
    // Single rectangular table with seats around
    const cx = 400, cy = 300, w = 200, h = 60, seatsPerSide = 4;
    // Top
    for (let i = 0; i < seatsPerSide; i++) {
      seats.push({
        seat_id: guid('br'),
        x: cx - w / 2 + (i + 1) * (w / (seatsPerSide + 1)),
        y: cy - h / 2 - 30,
        row_label: 'BR',
        seat_label: 'T' + (i + 1),
        shape: { type: 'rect', r: 10 },
        seat_type_id: 'boardroom',
        tier: 'Standard'
      });
    }
    // Bottom
    for (let i = 0; i < seatsPerSide; i++) {
      seats.push({
        seat_id: guid('br'),
        x: cx - w / 2 + (i + 1) * (w / (seatsPerSide + 1)),
        y: cy + h / 2 + 30,
        row_label: 'BR',
        seat_label: 'B' + (i + 1),
        shape: { type: 'rect', r: 10 },
        seat_type_id: 'boardroom',
        tier: 'Standard'
      });
    }
    // Left
    for (let i = 0; i < 2; i++) {
      seats.push({
        seat_id: guid('br'),
        x: cx - w / 2 - 30,
        y: cy - h / 2 + (i + 1) * (h / 3),
        row_label: 'BR',
        seat_label: 'L' + (i + 1),
        shape: { type: 'rect', r: 10 },
        seat_type_id: 'boardroom',
        tier: 'Standard'
      });
    }
    // Right
    for (let i = 0; i < 2; i++) {
      seats.push({
        seat_id: guid('br'),
        x: cx + w / 2 + 30,
        y: cy - h / 2 + (i + 1) * (h / 3),
        row_label: 'BR',
        seat_label: 'R' + (i + 1),
        shape: { type: 'rect', r: 10 },
        seat_type_id: 'boardroom',
        tier: 'Standard'
      });
    }
    return { seats, sections: [] };
  }

  if (type === 'cabaret') {
    // Semi-circle of seats around a table
    const cx = 400, cy = 300, chairs = 6, radius = 60;
    for (let k = 0; k < chairs; k++) {
      const angle = Math.PI * (1 + (k / (chairs - 1)) * -1); // semi-circle
      seats.push({
        seat_id: guid('cab'),
        x: cx + Math.cos(angle) * radius,
        y: cy + Math.sin(angle) * radius,
        row_label: 'C1',
        seat_label: String(k + 1),
        shape: { type: 'circle', r: 12 },
        seat_type_id: 'cabaret',
        tier: 'Standard'
      });
    }
    return { seats, sections: [] };
  }

  if (type === 'cocktail') {
    // High-top tables with 2 seats each
    const tables = 4, startX = 200, startY = 200, spacing = 120;
    for (let t = 0; t < tables; t++) {
      const cx = startX + t * spacing, cy = startY;
      for (let k = 0; k < 2; k++) {
        const angle = (k / 2) * Math.PI * 2;
        seats.push({
          seat_id: guid('ct'),
          x: cx + Math.cos(angle) * 24,
          y: cy + Math.sin(angle) * 24,
          row_label: 'T' + (t + 1),
          seat_label: String(k + 1),
          shape: { type: 'circle', r: 10 },
          seat_type_id: 'cocktail',
          tier: 'Standard'
        });
      }
    }
    return { seats, sections: [] };
  }

  if (type === 'hollow_square') {
    // Square of seats, center open
    const size = 5, startX = 200, startY = 200, spacing = 48;
    // Top
    for (let i = 0; i < size; i++) {
      seats.push({
        seat_id: guid('hs'),
        x: startX + i * spacing,
        y: startY,
        row_label: 'HS',
        seat_label: 'T' + (i + 1),
        shape: { type: 'rect', r: 10 },
        seat_type_id: 'hollow_square',
        tier: 'Standard'
      });
    }
    // Bottom
    for (let i = 0; i < size; i++) {
      seats.push({
        seat_id: guid('hs'),
        x: startX + i * spacing,
        y: startY + (size - 1) * spacing,
        row_label: 'HS',
        seat_label: 'B' + (i + 1),
        shape: { type: 'rect', r: 10 },
        seat_type_id: 'hollow_square',
        tier: 'Standard'
      });
    }
    // Left
    for (let i = 1; i < size - 1; i++) {
      seats.push({
        seat_id: guid('hs'),
        x: startX,
        y: startY + i * spacing,
        row_label: 'HS',
        seat_label: 'L' + (i + 1),
        shape: { type: 'rect', r: 10 },
        seat_type_id: 'hollow_square',
        tier: 'Standard'
      });
    }
    // Right
    for (let i = 1; i < size - 1; i++) {
      seats.push({
        seat_id: guid('hs'),
        x: startX + (size - 1) * spacing,
        y: startY + i * spacing,
        row_label: 'HS',
        seat_label: 'R' + (i + 1),
        shape: { type: 'rect', r: 10 },
        seat_type_id: 'hollow_square',
        tier: 'Standard'
      });
    }
    return { seats, sections: [] };
  }

  if (type === 'herringbone') {
    // Angled rows
    const rows = 5, cols = 8, startX = 120, startY = 120, spacing = 48;
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        seats.push({
          seat_id: guid('hb'),
          x: startX + c * spacing + r * 10,
          y: startY + r * spacing,
          row_label: String.fromCharCode(65 + r),
          seat_label: String(c + 1),
          shape: { type: 'rect', r: 10 },
          seat_type_id: 'herringbone',
          tier: 'Standard'
        });
      }
    }
    return { seats, sections: [] };
  }

  if (type === 'bar') {
    // Bar with stools
    const stools = 8, startX = 200, startY = 300, spacing = 36;
    for (let i = 0; i < stools; i++) {
      seats.push({
        seat_id: guid('bar'),
        x: startX + i * spacing,
        y: startY,
        row_label: 'Bar',
        seat_label: String(i + 1),
        shape: { type: 'circle', r: 10 },
        seat_type_id: 'bar',
        tier: 'Standard'
      });
    }
    return { seats, sections: [{ id: 'bar', label: 'Bar', type: 'bar' }] };
  }

  if (type === 'open_space') {
    // No seats, just open
    return { seats: [], sections: [{ id: 'open', label: 'Open Space', type: 'open_space' }] };
  }

  // fallback grid
  const rows = cfg.rows || 8, cols = cfg.cols || 10;
  for (let r=0;r<rows;r++){
    for (let c=0;c<cols;c++){
      seats.push({
        seat_id: guid('g'),
        x: 80 + c*48,
        y: 60 + r*48,
        row_label: String(r+1),
        seat_label: String(c+1),
        shape: { type: 'circle', r: 10 },
        seat_type_id: 'standard',
        tier: 'Standard'
      });
    }
  }
  return { seats, sections: [] };
}

/* ---------------------- SeatmapDesigner component ---------------------- */

export default function SeatmapDesigner({ venue, sections }) {
  // UI state
  const [venues, setVenues] = useState([]);
  const [venueId, setVenueId] = useState('');
  const [seatmaps, setSeatmaps] = useState([]);
  const [selectedMap, setSelectedMap] = useState(null);
  const [layout, setLayout] = useState({ seats: [], sections: sections || [] });
  const [svgBase, setSvgBase] = useState('');
  const [seatTypes, setSeatTypes] = useState(DEFAULT_SEAT_TYPES);
  const [tiers, setTiers] = useState([
    { tier_id: 'VIP', name: 'VIP', base_price_cents: 25000, color: '#d32f2f' },
    { tier_id: 'Standard', name: 'Standard', base_price_cents: 10000, color: '#1e88e5' },
    { tier_id: 'Economy', name: 'Economy', base_price_cents: 7000, color: '#43a047' }
  ]);
  const [selectedSectionId, setSelectedSectionId] = useState('');
  const [sectionDefs, setSectionDefs] = useState(sections || []);

  // FIX: Add missing newSection state
  const [newSection, setNewSection] = useState({ name: '', rows: 10, cols: 10, x: 100, y: 100 });

  // canvas state
  const svgRef = useRef(null);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [zoom, setZoom] = useState(1);
  const [isPanning, setIsPanning] = useState(false);
  const panOrigin = useRef(null);

  // selection + drag
  const [selectedSeatIds, setSelectedSeatIds] = useState([]); // supports multi-select
  const dragCtx = useRef(null); // { seatId, startClient, startPos }

  // rubberband selection
  const [rubber, setRubber] = useState(null); // { x,y,w,h } in screen coords
  const canvasRef = useRef(null);

  // undo/redo
  const historyRef = useRef([]);
  const redoRef = useRef([]);

  // csrf token (if you use server csrf endpoint)
  const [csrfToken, setCsrfToken] = useState('');

  useEffect(()=> {
    // optionally fetch venues from API (if you have an endpoint)
    fetchVenues()
      .then(setVenues)
      .catch(() => setVenues([]));
  }, []);

  useEffect(() => {
    if (venueId) {
      fetchSeatmaps(venueId)
        .then(setSeatmaps)
        .catch(() => setSeatmaps([]));
    }
  }, [venueId]);

  // When sections prop changes, update sectionDefs and layout.sections
  useEffect(() => {
    setSectionDefs(sections || []);
    setLayout(prev => ({
      ...prev,
      sections: sections || [],
      seats: prev.seats // keep seats unless you want to clear
    }));
  }, [sections]);

  // history helpers
  function pushHistory(snapshot) {
    historyRef.current.push(JSON.stringify(snapshot));
    // cap
    if (historyRef.current.length > 80) historyRef.current.shift();
    redoRef.current = [];
  }
  function undo(){
    if (!historyRef.current.length) return;
    const last = historyRef.current.pop();
    redoRef.current.unshift(JSON.stringify(layout));
    try {
      const s = JSON.parse(last);
      setLayout(s);
    } catch(e){}
  }
  function redo(){
    if (!redoRef.current.length) return;
    const top = redoRef.current.shift();
    historyRef.current.push(JSON.stringify(layout));
    try {
      const s = JSON.parse(top);
      setLayout(s);
    } catch(e){}
  }

  // utility to update layout with history
  function updateLayout(mutFn) {
    setLayout(prev => {
      const next = typeof mutFn === 'function' ? mutFn(prev) : mutFn;
      pushHistory(prev);
      return next;
    });
  }

  // seat move intermediate & commit
  const moveSeatLive = useRef(debounce((seatId,x,y)=>{
    setLayout(l => ({ ...l, seats: l.seats.map(s => s.seat_id === seatId ? ({ ...s, x, y }) : s ) }));
  }, 40));

  function startSeatDrag(seat, clientX, clientY) {
    // capture drag context
    dragCtx.current = {
      seatId: seat.seat_id,
      startClient: { x: clientX, y: clientY },
      startPos: { x: seat.x || 0, y: seat.y || 0 }
    };
  }

  function onPointerMoveGlobal(e) {
    // pan handling
    if (isPanning && panOrigin.current) {
      const dx = e.clientX - panOrigin.current.x;
      const dy = e.clientY - panOrigin.current.y;
      setPan({ x: panOrigin.current.panX + dx, y: panOrigin.current.panY + dy });
    }
    // dragging seat
    if (dragCtx.current && dragCtx.current.seatId) {
      const svgRect = svgRef.current.getBoundingClientRect();
      const x = (e.clientX - svgRect.left - pan.x) / zoom;
      const y = (e.clientY - svgRect.top - pan.y) / zoom;
      moveSeatLive.current(dragCtx.current.seatId, x, y);
    }
    // rubberband update handled by pointer events on canvas
  }

  function onPointerUpGlobal(e) {
    // end pan
    if (isPanning) {
      setIsPanning(false);
      panOrigin.current = null;
    }
    // finalize drag
    if (dragCtx.current && dragCtx.current.seatId) {
      const svgRect = svgRef.current.getBoundingClientRect();
      const x = (e.clientX - svgRect.left - pan.x) / zoom;
      const y = (e.clientY - svgRect.top - pan.y) / zoom;
      updateLayout(prev => ({ ...prev, seats: prev.seats.map(s => s.seat_id === dragCtx.current.seatId ? ({ ...s, x, y }) : s ) }));
      dragCtx.current = null;
    }
    // rubberband finalize
    if (rubber) {
      applyRubberSelection(rubber);
      setRubber(null);
    }
  }

  useEffect(()=>{
    window.addEventListener('pointermove', onPointerMoveGlobal);
    window.addEventListener('pointerup', onPointerUpGlobal);
    return ()=> {
      window.removeEventListener('pointermove', onPointerMoveGlobal);
      window.removeEventListener('pointerup', onPointerUpGlobal);
    };
  }, [isPanning, pan, zoom, rubber]);

  // pan start
  function startPan(e){
    if (e.button !== undefined && e.button !== 0) return; // only left pointer
    setIsPanning(true);
    panOrigin.current = { x: e.clientX, y: e.clientY, panX: pan.x, panY: pan.y };
  }

  // wheel zoom (ctrl/shift + wheel optional)
  function onWheelCanvas(e){
    if (!e.deltaY) return;
    // if shift key => zoom
    if (e.shiftKey) {
      e.preventDefault();
      const delta = -Math.sign(e.deltaY) * 0.06;
      setZoom(z => Math.min(3, Math.max(0.4, z + delta)));
    }
  }

  // rubberband logic
  function startRubber(e){
    // ctrl/meta to start rubberband selection
    if (!e.shiftKey) return;
    const rect = canvasRef.current.getBoundingClientRect();
    const sx = e.clientX - rect.left;
    const sy = e.clientY - rect.top;
    setRubber({ x: sx, y: sy, w: 0, h: 0 });
    const move = (ev) => {
      const nx = ev.clientX - rect.left;
      const ny = ev.clientY - rect.top;
      setRubber(r => r ? ({ ...r, w: nx - r.x, h: ny - r.y }) : null);
    };
    const up = (ev) => {
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
      // rubber finalize is handled on global pointer up
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
  }

  function applyRubberSelection(r) {
    if (!r) return;
    const rect = svgRef.current.getBoundingClientRect();
    // convert rubber screen rect to svg coords (account pan+zoom)
    const sx = (r.x - pan.x) / zoom;
    const sy = (r.y - pan.y) / zoom;
    const ex = (r.x + r.w - pan.x) / zoom;
    const ey = (r.y + r.h) / zoom;
    const left = Math.min(sx, ex), right = Math.max(sx, ex), top = Math.min(sy, ey), bottom = Math.max(sy, ey);
    const found = (layout.seats || []).filter(s => s.x >= left && s.x <= right && s.y >= top && s.y <= bottom).map(s => s.seat_id);
    setSelectedSeatIds(found);
  }

  // generate template into current layout
  function applyTemplate(type) {
    const tpl = generateTemplate(type, { width: 1200, height: 800 });
    updateLayout(prev => ({ ...prev, seats: [...prev.seats, ...tpl.seats], sections: [...(prev.sections||[]), ...(tpl.sections||[])] }));
  }

  // import/export
  async function importJSON(f) {
    if (!f) return;
    const txt = await f.text();
    try {
      const j = JSON.parse(txt);
      updateLayout(j);
    } catch (e) { alert('Invalid JSON'); }
  }
  function exportJSON() {
    const blob = new Blob([JSON.stringify(layout, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = `${selectedMap?.name || 'seatmap'}.json`; a.click();
  }

  function exportSVG() {
    const svgEl = svgRef.current;
    if (!svgEl) return;
    const s = new XMLSerializer().serializeToString(svgEl);
    const blob = new Blob([s], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = `${selectedMap?.name || 'seatmap'}.svg`; a.click();
  }

  async function exportPNG() {
    const svgEl = svgRef.current;
    if (!svgEl) return;
    const s = new XMLSerializer().serializeToString(svgEl);
    const img = new Image();
    const blob = new Blob([s], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    await new Promise((res, rej) => {
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const rect = svgEl.getBoundingClientRect();
        canvas.width = rect.width;
        canvas.height = rect.height;
        const ctx = canvas.getContext('2d');
        ctx.fillStyle = '#fff'; ctx.fillRect(0,0,canvas.width,canvas.height);
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        canvas.toBlob(b => {
          const u = URL.createObjectURL(b);
          const a = document.createElement('a'); a.href = u; a.download = `${selectedMap?.name || 'seatmap'}.png`; a.click();
          res();
        }, 'image/png');
      };
      img.onerror = rej;
      img.src = url;
    });
  }

  // seat CRUD
  function addSeatAt(x, y) {
    const s = {
      seat_id: guid('s'),
      x, y,
      row_label: '',
      seat_label: '',
      shape: { type: 'circle', r: 10 },
      seat_type_id: 'standard',
      tier: 'Standard'
    };
    updateLayout(prev => ({ ...prev, seats: [...(prev.seats||[]), s] }));
  }

  function removeSelectedSeats(){
    updateLayout(prev => ({ ...prev, seats: prev.seats.filter(s => !selectedSeatIds.includes(s.seat_id)) }));
    setSelectedSeatIds([]);
  }

  // assign selected seats to a tier
  function assignTierToSelected(tierId) {
    updateLayout(prev => ({ ...prev, seats: prev.seats.map(s => selectedSeatIds.includes(s.seat_id) ? ({ ...s, tier: tierId }) : s) }));
  }

  // assign seat type to selected
  function assignTypeToSelected(typeId) {
    const type = seatTypes.find(t => t.seat_type_id === typeId);
    updateLayout(prev => ({ ...prev, seats: prev.seats.map(s => selectedSeatIds.includes(s.seat_id) ? ({ ...s, seat_type_id: typeId, color: type?.color || s.color }) : s) }));
  }

  // seat click handlers
  function handleSeatClick(seat, meta={shiftKey:false, ctrlKey:false}) {
    if (meta.shiftKey) {
      // toggle in multi-select
      setSelectedSeatIds(prev => prev.includes(seat.seat_id) ? prev.filter(id => id !== seat.seat_id) : [...prev, seat.seat_id]);
    } else {
      setSelectedSeatIds([seat.seat_id]);
    }
  }

  function handleSeatDoubleClick(seat) {
    // delete single seat
    if (window.confirm('Delete this seat?')) {
      updateLayout(prev => ({ ...prev, seats: prev.seats.filter(s => s.seat_id !== seat.seat_id) }));
      setSelectedSeatIds([]);
    }
  }

  // add a seat on canvas click (double-click on empty area)
  function canvasDoubleClick(e) {
    // compute coords in svg space
    const rect = svgRef.current.getBoundingClientRect();
    const x = (e.clientX - rect.left - pan.x)/zoom;
    const y = (e.clientY - rect.top - pan.y)/zoom;
    addSeatAt(x,y);
  }

  // load a seatmap into canvas
  async function loadSeatmap(id) {
    const sm = await fetchSeatmap(id);
    if (!sm) { alert('Failed to load'); return; }
    setSelectedMap(sm);
    setSvgBase(sm.svg_content || '');
    setLayout(sm.layout || { seats: sm.seats || [], sections: sm.sections || [] });
    historyRef.current = [];
    redoRef.current = [];
  }

  // save functions (use your server API)
  async function saveNew() {
    if (!venueId) return alert('Select a venue first');
    const payload = { venue_id: venueId, name: selectedMap?.name || 'Seatmap ' + Date.now(), svg_content: svgBase, layout };
    const res = await saveSeatmap(payload, csrfToken);
    if (res.error) alert('Failed to save: ' + res.error); else {
      alert('Saved'); setSeatmaps(s => [res, ...s]); setSelectedMap(res);
    }
  }
  async function updateExisting() {
    if (!selectedMap) return alert('Select a seatmap');
    const res = await updateSeatmap(selectedMap.seatmap_id, { svg_content: svgBase, layout }, csrfToken);
    if (res.error) alert('Failed to update'); else { alert('Updated'); setSelectedMap(res); }
  }

  // simple UI for editing seat-types and tiers inline
  function addSeatType() {
    const id = guid('st');
    const newType = { seat_type_id: id, label: 'New Type', color: '#9e9e9e', default_price_cents: 0 };
    setSeatTypes(prev => [newType, ...prev]);
  }
  function updateSeatType(id, patch) {
    setSeatTypes(prev => prev.map(t => t.seat_type_id === id ? ({ ...t, ...patch }) : t));
  }
  function removeSeatType(id) {
    setSeatTypes(prev => prev.filter(t => t.seat_type_id !== id));
  }

  function addTier() {
    const id = guid('tr');
    setTiers(prev => [{ tier_id: id, name: 'New', base_price_cents: 0, color: '#90caf9' }, ...prev]);
  }
  function updateTier(id, patch) {
    setTiers(prev => prev.map(t => t.tier_id === id ? ({ ...t, ...patch }) : t));
  }
  function removeTier(id) {
    setTiers(prev => prev.filter(t => t.tier_id !== id));
  }

  // Add a new section with rows/cols
  function addSection() {
    if (!newSection.name || !venueId) return;
    const id = guid('sec');
    setSectionDefs(prev => [...prev, { ...newSection, id, venue_id: venueId }]);
    // Optionally, add seats for this section
    const seats = [];
    for (let r = 0; r < newSection.rows; r++) {
      for (let c = 0; c < newSection.cols; c++) {
        seats.push({
          seat_id: guid('s'),
          x: newSection.x + c * 32,
          y: newSection.y + r * 32,
          row_label: String.fromCharCode(65 + r),
          seat_label: String(c + 1),
          shape: { type: 'circle', r: 10 },
          seat_type_id: 'standard',
          tier: 'Standard',
          section_id: id 
        });
      }
    }
    updateLayout(prev => ({
      ...prev,
      seats: [...(prev.seats || []), ...seats],
      sections: [...(prev.sections || []), { id, label: newSection.name, type: 'section', ...newSection, venue_id: venueId }]
    }));
    setNewSection({ name: '', rows: 10, cols: 10, x: 100, y: 100 });
  }

  // Export PNG of all sections (canvas snapshot)
  const exportSectionsPNG = useCallback(async () => {
    const svgEl = svgRef.current;
    if (!svgEl) return;
    const s = new XMLSerializer().serializeToString(svgEl);
    const img = new window.Image();
    const blob = new Blob([s], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    await new Promise((res, rej) => {
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const rect = svgEl.getBoundingClientRect();
        canvas.width = rect.width;
        canvas.height = rect.height;
        const ctx = canvas.getContext('2d');
        ctx.fillStyle = '#fff'; ctx.fillRect(0,0,canvas.width,canvas.height);
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        canvas.toBlob(b => {
          const u = URL.createObjectURL(b);
          const a = document.createElement('a'); a.href = u; a.download = `sections.png`; a.click();
          res();
        }, 'image/png');
      };
      img.onerror = rej;
      img.src = url;
    });
  }, [svgRef]);

  // render
  return (
    <Card style={{ padding: 12, margin: '20px auto', maxWidth: 1400 }}>
      <Typography variant="h5" gutterBottom>Advanced Multi-Venue Seatmap Designer</Typography>

      {/* Section definition UI */}
      <Paper style={{ padding: 8, marginBottom: 8 }}>
        <Typography variant="subtitle1">Add Section</Typography>
        <Box sx={{ display: 'flex', gap: 1, alignItems: 'center', mb: 1 }}>
          <TextField label="Section Name" size="small" value={newSection.name} onChange={e => setNewSection(s => ({ ...s, name: e.target.value }))} />
          <TextField label="Rows" type="number" size="small" value={newSection.rows} onChange={e => setNewSection(s => ({ ...s, rows: Number(e.target.value) }))} style={{ width: 80 }} />
          <TextField label="Cols" type="number" size="small" value={newSection.cols} onChange={e => setNewSection(s => ({ ...s, cols: Number(e.target.value) }))} style={{ width: 80 }} />
          <TextField label="X" type="number" size="small" value={newSection.x} onChange={e => setNewSection(s => ({ ...s, x: Number(e.target.value) }))} style={{ width: 80 }} />
          <TextField label="Y" type="number" size="small" value={newSection.y} onChange={e => setNewSection(s => ({ ...s, y: Number(e.target.value) }))} style={{ width: 80 }} />
          <Button variant="contained" onClick={addSection}>Add Section</Button>
          <Button variant="outlined" onClick={exportSectionsPNG}>Export Sections PNG</Button>
        </Box>
        <Box>
          {sectionDefs.map(sec => (
            <Typography key={sec.id} variant="body2">{sec.name} ({sec.rows}x{sec.cols}) at ({sec.x},{sec.y})</Typography>
          ))}
        </Box>
      </Paper>

      <Paper style={{ padding: 8, marginBottom: 8 }}>
        <ListItem>
          <Autocomplete
            options={venues}
            getOptionLabel={v => v.name || ''}
            value={venues.find(v => v.venue_id === venueId) || null}
            onChange={(_, v) => setVenueId(v ? v.venue_id : '')}
            style={{ width: 280 }}
            renderInput={params => <TextField {...params} label="Select Venue" />}
          />
          <Button onClick={() => applyTemplate('theater')} style={{ marginLeft: 8 }}>Apply Theater Template</Button>
          <Button onClick={() => applyTemplate('stadium')} style={{ marginLeft: 8 }}>Apply Stadium</Button>
          <Button onClick={() => applyTemplate('plane')} style={{ marginLeft: 8 }}>Apply Plane</Button>
          <Button onClick={() => applyTemplate('bus')} style={{ marginLeft: 8 }}>Apply Bus</Button>
          <Button onClick={() => applyTemplate('banquet')} style={{ marginLeft: 8 }}>Apply Banquet</Button>
          <Button onClick={() => applyTemplate('table_banquet')} style={{ marginLeft: 8 }}>Apply Table</Button>
          <Button onClick={() => applyTemplate('u_shape')} style={{ marginLeft: 8 }}>Apply U-Shape</Button>
          <Button onClick={() => applyTemplate('boardroom')} style={{ marginLeft: 8 }}>Apply Boardroom</Button>
          <Button onClick={() => applyTemplate('cabaret')} style={{ marginLeft: 8 }}>Apply Cabaret</Button>
          <Button onClick={() => applyTemplate('cocktail')} style={{ marginLeft: 8 }}>Apply Cocktail</Button>
          <Button onClick={() => applyTemplate('hollow_square')} style={{ marginLeft: 8 }}>Apply Hollow Square</Button>
          <Button onClick={() => applyTemplate('herringbone')} style={{ marginLeft: 8 }}>Apply Herringbone</Button>
          <Button onClick={() => applyTemplate('bar')} style={{ marginLeft: 8 }}>Apply Bar</Button>
          <Button onClick={() => applyTemplate('open_space')} style={{ marginLeft: 8 }}>Apply Open Space</Button>
          <Box style={{ flex: 1 }} />
        </ListItem>
      </Paper>

      <Paper style={{ padding: 8, marginBottom: 8 }}>
        <ListItem>
          <Autocomplete
            options={seatmaps}
            getOptionLabel={m => m.name || ''}
            value={selectedMap || null}
            onChange={async (_, m) => {
              if (m) {
                const sm = await fetchSeatmap(m.seatmap_id);
                if (sm) {
                  setSelectedMap(sm);
                  setSvgBase(sm.svg_content || '');
                  setLayout(sm.layout || { seats: sm.seats || [], sections: sm.sections || [] });
                  historyRef.current = [];
                  redoRef.current = [];
                }
              }
            }}
            style={{ width: 280 }}
            renderInput={params => <TextField {...params} label="Select Seatmap" />}
          />
          <Button
            variant="contained"
            onClick={() => {
              setSelectedMap(null);
              setLayout({ seats: [], sections: [] });
              setSvgBase('');
            }}
            style={{ marginLeft: 8 }}
          >
            New Seatmap
          </Button>
          <Box style={{ flex: 1 }} />
          {selectedMap && <Typography variant="body2" color="textSecondary">Loaded: {selectedMap.name}</Typography>}

          {/* Moved controls here */}
          <IconButton onClick={undo}><UndoIcon /></IconButton>
          <IconButton onClick={redo}><RedoIcon /></IconButton>
          <IconButton onClick={() => setZoom(z => Math.min(3, z + 0.1))}><ZoomInIcon /></IconButton>
          <IconButton onClick={() => setZoom(z => Math.max(0.3, z - 0.1))}><ZoomOutIcon /></IconButton>
          <Button startIcon={<DownloadIcon />} onClick={exportJSON} style={{ marginLeft: 8 }}>Export JSON</Button>
          <Button onClick={exportSVG} style={{ marginLeft: 8 }}>Export SVG</Button>
          <Button onClick={exportPNG} style={{ marginLeft: 8 }}>Export PNG</Button>
        </ListItem>
      </Paper>

      <Grid container spacing={2}>
        <Grid item xs={3}>
          <Paper style={{ padding: 8, marginBottom: 8 }}>
            <Typography variant="subtitle1">Seat Types</Typography>
            <Button onClick={addSeatType} size="small">Add Type</Button>
            <Divider style={{ margin: '8px 0' }} />
            {[
              ...seatTypes,
              // Add all extra seat types if not already present
              { seat_type_id: 'table_banquet', label: 'Banquet Table', color: '#fbc02d', default_price_cents: 0, description: 'Round tables with 8-10 guests per table. Best for social events, wedding receptions, and formal dinners.' },
              { seat_type_id: 'theater', label: 'Theater Style', color: '#1976d2', default_price_cents: 0, description: 'Rows of chairs facing a stage. Best for lectures and performances.' },
              { seat_type_id: 'classroom', label: 'Classroom Style', color: '#388e3c', default_price_cents: 0, description: 'Tables in rows with chairs on one side. Best for conferences and training.' },
              { seat_type_id: 'boardroom', label: 'Boardroom Style', color: '#6d4c41', default_price_cents: 0, description: 'Single rectangular table with participants around it. Best for small meetings.' },
              { seat_type_id: 'cabaret', label: 'Cabaret Style', color: '#e57373', default_price_cents: 0, description: 'Semi-circle of chairs around small tables. Best for award ceremonies and presentations.' },
              { seat_type_id: 'cocktail', label: 'Cocktail Style', color: '#00bcd4', default_price_cents: 0, description: 'High-top tables with limited seating. Encourages mingling.' },
              { seat_type_id: 'u_shape', label: 'U-Shape', color: '#7b1fa2', default_price_cents: 0, description: 'Tables arranged in a "U" with chairs on the outside. Best for interaction with a facilitator.' },
              { seat_type_id: 'hollow_square', label: 'Hollow Square', color: '#c62828', default_price_cents: 0, description: 'Square or rectangular table with center open. Best for collaboration.' },
              { seat_type_id: 'herringbone', label: 'Herringbone', color: '#2e7d32', default_price_cents: 0, description: 'Chairs angled in rows for clear view and space.' },
              { seat_type_id: 'bar', label: 'Bar', color: '#ff9800', default_price_cents: 0, description: 'Bar seating.' },
              { seat_type_id: 'open_space', label: 'Open Space', color: '#bdbdbd', default_price_cents: 0, description: 'Open area for flexible arrangements.' }
            ].reduce((acc, t) => acc.find(tt => tt.seat_type_id === t.seat_type_id) ? acc : [...acc, t], []) // avoid duplicates
            .map(t => (
              <Box key={t.seat_type_id} style={{ display:'flex', alignItems:'center', gap:8, marginBottom:6 }}>
                <div style={{ width:18, height:18, background: t.color, borderRadius:4 }} />
                <TextField size="small" value={t.label} onChange={e => updateSeatType(t.seat_type_id, { label: e.target.value })} />
                <TextField size="small" value={Math.round((t.default_price_cents||0)/100)} onChange={e => updateSeatType(t.seat_type_id, { default_price_cents: Math.round(parseFloat(e.target.value||0)*100) })} inputProps={{ style:{ width:80 } }} />
                <Button onClick={() => removeSeatType(t.seat_type_id)} color="error">X</Button>
              </Box>
            ))}
          </Paper>

          <Paper style={{ padding:8, marginBottom:8 }}>
            <Typography variant="subtitle1">Pricing Tiers</Typography>
            <Button onClick={addTier} size="small">Add Tier</Button>
            <Divider style={{ margin: '8px 0' }} />
            {tiers.map(t => (
              <Box key={t.tier_id} style={{ display:'flex', gap:8, alignItems:'center', marginBottom:6 }}>
                <div style={{ width:18, height:18, background: t.color, borderRadius:4 }} />
                <TextField size="small" value={t.name} onChange={e => updateTier(t.tier_id, { name: e.target.value })} />
                <TextField size="small" value={Math.round((t.base_price_cents||0)/100)} onChange={e => updateTier(t.tier_id, { base_price_cents: Math.round(parseFloat(e.target.value||0)*100) })} inputProps={{ style:{ width:80 } }} />
                <Button onClick={() => removeTier(t.tier_id)} color="error">X</Button>
              </Box>
            ))}
          </Paper>

          <Paper style={{ padding:8 }}>
            <Typography variant="subtitle1">Selected Seats</Typography>
            <div>
              <div style={{ marginBottom:8 }}>Selected count: {selectedSeatIds.length}</div>
              <FormControl fullWidth size="small" style={{ marginBottom:8 }}>
                <InputLabel>Assign Tier</InputLabel>
                <Select label="Assign Tier" value={selectedSeatIds.length ? (layout.seats.find(s=>s.seat_id===selectedSeatIds[0])?.tier || '') : ''} onChange={e => assignTierToSelected(e.target.value)}>
                  {tiers.map(t => <MenuItem key={t.tier_id} value={t.tier_id}>{t.name}</MenuItem>)}
                </Select>
              </FormControl>
              <FormControl fullWidth size="small" style={{ marginBottom:8 }}>
                <InputLabel>Assign Type</InputLabel>
                <Select label="Assign Type" value={selectedSeatIds.length ? (layout.seats.find(s=>s.seat_id===selectedSeatIds[0])?.seat_type_id || '') : ''} onChange={e => assignTypeToSelected(e.target.value)}>
                  {seatTypes.map(tt => <MenuItem key={tt.seat_type_id} value={tt.seat_type_id}>{tt.label}</MenuItem>)}
                </Select>
              </FormControl>

              <Button onClick={removeSelectedSeats} color="error">Delete Selected</Button>
              <Button onClick={() => updateLayout(prev => ({ ...prev, seats: prev.seats.map(s => selectedSeatIds.includes(s.seat_id) ? ({ ...s, x: s.x+10 }) : s) }))} style={{ marginLeft:8 }}>Nudge Right</Button>
            </div>
          </Paper>
        </Grid>

        <Grid item xs={9}>
          <Paper style={{ padding:8 }}>
            <Typography variant="subtitle1">Canvas (Shift + drag to multi-select; Drag seats to move; double-click empty to add)</Typography>
            <div
              ref={canvasRef}
              style={{ width:'100%', height:680, border:'1px solid #ddd', position:'relative', overflow:'auto', touchAction:'none' }}
              onWheel={onWheelCanvas}
              onDoubleClick={canvasDoubleClick}
            >
              <svg
                ref={svgRef}
                width={1400}
                height={1000}
                style={{ display:'block', transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`, transformOrigin: '0 0', background: '#fff' }}
                onPointerDown={(e) => {
                  // pan vs rubberband: left button + no shift -> start pan
                  if (!e.shiftKey) {
                    startPan(e);
                  } else {
                    startRubber(e);
                  }
                }}
                onPointerUp={(e) => {
                  // stop pan handled globally
                }}
              >
                {/* svg base layer (user can paste raw svg) */}
                <g dangerouslySetInnerHTML={{ __html: svgBase || '<rect width="100%" height="100%" fill="#fff"/>' }} />

                {/* sections (optional) */}
                { (layout.sections || []).map((sec, idx) => (
                  <g key={idx}>
                    {/* simple rendering for stage/zone */}
                    { sec.type === 'stage' && <rect x={0} y={0} width={1400} height={60} fill="#222" opacity={0.05} /> }
                  </g>
                ))}

                {/* seats */}
                { (layout.seats || []).map(seat => (
                  <DraggableSeat
                    key={seat.seat_id}
                    seat={{
                      ...seat,
                      tier_color: tiers.find(t => t.tier_id === seat.tier)?.color,
                      color: seat.color || seatTypes.find(st => st.seat_type_id === seat.seat_type_id)?.color
                    }}
                    selected={selectedSeatIds.includes(seat.seat_id)}
                    highlighted={selectedSeatIds.includes(seat.seat_id)}
                    zoom={zoom}
                    onPointerDown={(s, clientX, clientY) => startSeatDrag(s, clientX, clientY)}
                    onClick={(s) => handleSeatClick(s, { shiftKey: window.event && window.event.shiftKey })}
                    onDoubleClick={(s) => handleSeatDoubleClick(s)}
                  />
                ))}

                {/* rubberband rect in svg coordinates - for visualization we draw it in screen coords on top layer */}
              </svg>

              {/* draw rubberband overlay in screen coords */}
              { rubber && <div style={{
                  position:'absolute', left: rubber.x, top: rubber.y, width: rubber.w, height: rubber.h,
                  border: '1px dashed #1976d2', background: 'rgba(25,118,210,0.06)', pointerEvents: 'none'
                }} /> }

              {/* overlay UI (simple) */}
              <div style={{ position:'absolute', right: 8, top: 8, display:'flex', gap:8 }}>
                <Button variant="contained" size="small" onClick={() => { setPan({ x:0, y:0 }); setZoom(1); }}>Reset View</Button>
                <Button variant="outlined" size="small" onClick={() => { setLayout({ seats: [], sections: [] }); setSelectedSeatIds([]); }}>Clear</Button>
              </div>

            </div>

            <Box sx={{ mt:1, display:'flex', gap:1 }}>
              <Button startIcon={<SaveIcon />} variant="contained" onClick={saveNew} >Save New</Button>
              <Button variant="outlined" onClick={updateExisting}>Update</Button>
              <Button variant="outlined" component="label"><UploadIcon /> Import JSON<input type="file" hidden accept=".json" onChange={e => importJSON(e.target.files[0])} /></Button>
            </Box>

            {/* Moved controls below */}
            <Box sx={{ mt:2, display:'flex', gap:1 }}>
              <IconButton onClick={undo}><UndoIcon /></IconButton>
              <IconButton onClick={redo}><RedoIcon /></IconButton>
              <IconButton onClick={() => setZoom(z => Math.min(3, z + 0.1))}><ZoomInIcon /></IconButton>
              <IconButton onClick={() => setZoom(z => Math.max(0.3, z - 0.1))}><ZoomOutIcon /></IconButton>
              <Button startIcon={<DownloadIcon />} onClick={exportJSON}>Export JSON</Button>
              <Button onClick={exportSVG}>Export SVG</Button>
              <Button onClick={exportPNG}>Export PNG</Button>
            </Box>
          </Paper>
        </Grid>
      </Grid>
    </Card>
  );
}
