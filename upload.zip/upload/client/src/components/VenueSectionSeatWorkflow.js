import React, { useState, useEffect } from 'react';
import { Button, Stack, Dialog, DialogTitle, DialogContent, DialogActions, List, ListItem } from '@mui/material';
import VenueForm from './VenueForm';
import SectionForm from './SectionForm';
import SeatForm from './SeatForm';
import SeatmapDesigner from './SeatmapDesigner';
import { fetchVenues } from '../services/venueService';
import { fetchSections } from '../services/sectionService';

export default function VenueSectionSeatWorkflow() {
  const [venueFormOpen, setVenueFormOpen] = useState(false);
  const [sectionFormOpen, setSectionFormOpen] = useState(false);
  const [seatFormOpen, setSeatFormOpen] = useState(false);
  const [seatmapDesignerOpen, setSeatmapDesignerOpen] = useState(false);

  const [venues, setVenues] = useState([]);
  const [selectedVenue, setSelectedVenue] = useState(null);

  const [sections, setSections] = useState([]);
  const [selectedSection, setSelectedSection] = useState(null);

  // Fetch venues on mount and after adding
  useEffect(() => {
    async function loadVenues() {
      try {
        const venueList = await fetchVenues();
        setVenues(venueList);
      } catch (e) {
        setVenues([]);
      }
    }
    loadVenues();
  }, []);

  // Fetch sections when a venue is selected
  useEffect(() => {
    async function loadSections() {
      if (!selectedVenue) {
        setSections([]);
        setSelectedSection(null);
        return;
      }
      try {
        const fetchedSections = await fetchSections(selectedVenue.venue_id);
        setSections(fetchedSections);
        setSelectedSection(null);
      } catch {
        setSections([]);
        setSelectedSection(null);
      }
    }
    loadSections();
  }, [selectedVenue]);

  // Venue handlers
  function handleVenueClose(createdVenue) {
    setVenueFormOpen(false);
    if (createdVenue) {
      setVenues(prev => [...prev, createdVenue]);
    }
  }

  function handleVenueSelect(venueId) {
    const venue = venues.find(v => v.venue_id === venueId);
    setSelectedVenue(venue);
  }

  // Section handlers
  async function handleSectionClose(createdSection) {
    setSectionFormOpen(false);
    if (createdSection && selectedVenue) {
      try {
        const fetchedSections = await fetchSections(selectedVenue.venue_id);
        setSections(fetchedSections);
      } catch {
        setSections(prev => [...prev, createdSection]);
      }
    }
  }

  function handleSectionSelect(sectionId) {
    const section = sections.find(s => s.section_id === sectionId);
    setSelectedSection(section);
  }

  // Seat handlers
  function handleSeatClose() {
    setSeatFormOpen(false);
  }

  // Seatmap designer handler
  function handleSeatmapDesignerClose() {
    setSeatmapDesignerOpen(false);
  }

  // NEW: Open seatmap designer for the whole venue (all sections)
  function handleVenueSeatmapDesignerOpen() {
    setSelectedSection(null);
    setSeatmapDesignerOpen(true);
  }

  return (
    <div style={{ margin: 24 }}>
      <Stack direction="row" spacing={2} style={{ marginBottom: 24 }}>
        <Button
          variant="contained"
          color="primary"
          onClick={() => setVenueFormOpen(true)}
        >
          Add Venue
        </Button>
        {selectedVenue && (
          <Button
            variant="contained"
            color="secondary"
            onClick={handleVenueSeatmapDesignerOpen}
          >
            Open Seatmap Designer (All Sections)
          </Button>
        )}
      </Stack>

      {/* Venue List */}
      <div>
        <h3>Venues</h3>
        <List>
          {venues.map(venue => (
            <ListItem key={venue.venue_id} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <span
                style={{
                  fontWeight: selectedVenue?.venue_id === venue.venue_id ? 'bold' : 'normal',
                  cursor: 'pointer'
                }}
                onClick={() => handleVenueSelect(venue.venue_id)}
              >
                {venue.name}
              </span>
              <Button
                variant="outlined"
                size="small"
                onClick={() => {
                  setSelectedVenue(venue);
                  setSectionFormOpen(true);
                }}
              >
                Add Section
              </Button>
            </ListItem>
          ))}
        </List>
      </div>

      {/* Section List for selected venue */}
      {selectedVenue && (
        <div style={{ marginTop: 24 }}>
          <h4>Sections for {selectedVenue.name}</h4>
          <List>
            {sections.map(section => (
              <ListItem key={section.section_id} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <span
                  style={{
                    fontWeight: selectedSection?.section_id === section.section_id ? 'bold' : 'normal',
                    cursor: 'pointer'
                  }}
                  onClick={() => handleSectionSelect(section.section_id)}
                >
                  {section.name} ({section.row_count} rows x {section.col_count} cols)
                </span>
                <Button
                  variant="outlined"
                  size="small"
                  onClick={() => {
                    setSelectedSection(section);
                    setSeatFormOpen(true);
                  }}
                >
                  Add Seats
                </Button>
                <Button
                  variant="outlined"
                  size="small"
                  color="secondary"
                  onClick={() => {
                    setSelectedSection(section);
                    setSeatmapDesignerOpen(true);
                  }}
                  style={{ marginLeft: 8 }}
                >
                  Seatmap (Section)
                </Button>
              </ListItem>
            ))}
          </List>
        </div>
      )}

      {/* Venue Modal */}
      <VenueForm open={venueFormOpen} onClose={handleVenueClose} />

      {/* Section Modal */}
      {selectedVenue && (
        <SectionForm
          open={sectionFormOpen}
          venue={selectedVenue}
          onClose={handleSectionClose}
        />
      )}

      {/* Seat Modal */}
      {selectedSection && (
        <SeatForm
          open={seatFormOpen}
          section={selectedSection}
          onClose={handleSeatClose}
        />
      )}

      {/* Seatmap Designer Modal */}
      <Dialog open={seatmapDesignerOpen} onClose={handleSeatmapDesignerClose} maxWidth="lg" fullWidth>
        <DialogTitle>
          Seatmap Designer
          {selectedSection
            ? ` for ${selectedSection.name}`
            : selectedVenue
            ? ` for ${selectedVenue.name} (All Sections)`
            : ''}
        </DialogTitle>
        <DialogContent>
          <SeatmapDesigner
            venue={selectedVenue}
            sections={selectedSection ? [selectedSection] : sections}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleSeatmapDesignerClose}>Close</Button>
        </DialogActions>
      </Dialog>
    </div>
  );
}