import React, { useState, useEffect } from 'react';
import { Dialog, DialogTitle, DialogContent, DialogActions, List, ListItem, TextField, Button } from '@mui/material';
import { getCsrfToken } from '../services/csrf';
import SectionForm from './SectionForm'; // You need to create this component

export default function VenueForm({ open, onClose, venue }) {
  const [name, setName] = useState('');
  const [cap, setCap] = useState('');
  const [street, setStreet] = useState('');
  const [city, setCity] = useState('');
  const [state, setState] = useState('');
  const [zip, setZip] = useState('');
  const [country, setCountry] = useState('');
  const [error, setError] = useState('');
  const [createdVenue, setCreatedVenue] = useState(null);
  const [sectionFormOpen, setSectionFormOpen] = useState(false);

  // Prefill form for editing
  useEffect(() => {
    if (venue && venue.address) {
      setName(venue.name || '');
      setCap(venue.capacity ? String(venue.capacity) : '');
      setStreet(venue.address.street || '');
      setCity(venue.address.city || '');
      setState(venue.address.state || '');
      setZip(venue.address.zip || '');
      setCountry(venue.address.country || '');
    } else {
      setName('');
      setCap('');
      setStreet('');
      setCity('');
      setState('');
      setZip('');
      setCountry('');
    }
    setError('');
  }, [venue, open]);

  async function submit() {
    const addressObj = {
      street,
      city,
      state,
      zip,
      country,
    };
    const csrf = await getCsrfToken();
    const url = (process.env.REACT_APP_API_URL || 'http://localhost:5000') + '/api/venues' + (venue ? '/' + venue.venue_id : '');
    const method = venue ? 'PUT' : 'POST';
    const res = await fetch(url, {
      method,
      headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf },
      credentials: 'include',
      body: JSON.stringify({ name, capacity: parseInt(cap || 0), address: addressObj })
    });
    const j = await res.json();
    if (j.error) {
      setError(j.error);
    } else {
      setError('');
      alert('Saved');
      setCreatedVenue(j); // Save the created venue object
      setSectionFormOpen(true); // Open SectionForm after venue creation
      if (onClose) onClose();
    }
  }

  return (
    <>
      <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
        <DialogTitle>{venue ? 'Edit Venue' : 'Create Venue'}</DialogTitle>
        <DialogContent>
          <List>
            <ListItem>
              <TextField label='Name' value={name} onChange={e => setName(e.target.value)} fullWidth />
            </ListItem>
            <ListItem>
              <TextField label='Capacity' value={cap} onChange={e => setCap(e.target.value)} fullWidth />
            </ListItem>
            <ListItem>
              <TextField label='Street' value={street} onChange={e => setStreet(e.target.value)} fullWidth />
            </ListItem>
            <ListItem>
              <TextField label='City' value={city} onChange={e => setCity(e.target.value)} fullWidth />
            </ListItem>
            <ListItem>
              <TextField label='State' value={state} onChange={e => setState(e.target.value)} fullWidth />
            </ListItem>
            <ListItem>
              <TextField label='Zip' value={zip} onChange={e => setZip(e.target.value)} fullWidth />
            </ListItem>
            <ListItem>
              <TextField label='Country' value={country} onChange={e => setCountry(e.target.value)} fullWidth />
            </ListItem>
            {error && (
              <ListItem>
                <span style={{ color: 'red' }}>{error}</span>
              </ListItem>
            )}
          </List>
        </DialogContent>
        <DialogActions>
          <Button onClick={onClose}>Cancel</Button>
          <Button onClick={submit} variant="contained">{venue ? 'Save' : 'Create'}</Button>
        </DialogActions>
      </Dialog>
      {/* Show SectionForm after venue creation */}
      {createdVenue && (
        <SectionForm
          open={sectionFormOpen}
          venue={createdVenue}
          onClose={() => setSectionFormOpen(false)}
        />
      )}
    </>
  );
}
