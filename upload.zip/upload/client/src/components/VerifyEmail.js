import React, { useState, useEffect } from 'react';
import { Card, Paper, List, ListItem, Button } from '@mui/material';
import { useLocation } from 'react-router-dom';

function useQuery() { return new URLSearchParams(useLocation().search); }

export default function VerifyEmail() {
  const q = useQuery();
  const token = q.get('token');
  const [msg, setMsg] = useState('Verifying...');
  useEffect(() => {
    if (!token) { setMsg('No token provided'); return; }
    fetch((process.env.REACT_APP_API_URL||'http://localhost:5000') + '/api/auth/verify-email?token=' + token)
      .then(r => r.json()).then(d => { setMsg(d.message || d.error || JSON.stringify(d)); });
  }, [token]);
  return (
    <Card style={{ maxWidth:420, margin:'20px auto', padding:16 }}>
      <Paper style={{ padding:12 }}>
        <List>
          <ListItem>{msg}</ListItem>
          <ListItem><Button href="/login">Go to login</Button></ListItem>
        </List>
      </Paper>
    </Card>
  );
}
