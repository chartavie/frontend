import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './App';
import { ThemeProviderCustom } from './contexts/ThemeContext';
import { AuthProvider } from './contexts/AuthContext';

createRoot(document.getElementById('root')).render(
  <ThemeProviderCustom>
    <AuthProvider>
      <App />
    </AuthProvider>
  </ThemeProviderCustom>
);
